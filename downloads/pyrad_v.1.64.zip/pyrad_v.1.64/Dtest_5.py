import numpy
import sys
import random
import itertools
import multiprocessing
from potpour import Worker


def IUPAC(one):
    """
    returns IUPAC symbol for ambiguity bases,
    used for polymorphic sites.
    """
    D = {"R":['G','A'],
         "K":['G','T'],
         "S":['G','C'],
         "Y":['T','C'],
         "W":['T','A'],
         "M":['C','A']}
    return D[one]


def sample_wr(population, k):     
    "Chooses k random elements (with replacement) from a population"
    n = len(population)
    _random, _int = random.random, int  # speed hack
    return [_int(_random() * n) for i in itertools.repeat(None, k)]


def makefreq(patlist):
    " identify which allele is derived in P3 relative to outgroup "
    " and is the most frequent and use that as the SNP."
    " Also, split up alleles into those that are P3a & vs. or P3b "
    P = {}
    for tax in range(len(patlist)):
        P[tax] = []
    for tax in range(len(patlist)):
        for base in patlist[tax]:
            if base in list('ATGC'):
                P[tax].append(base[0])
                P[tax].append(base[0])
            elif base in list("RKSYWM"):
                hh = IUPAC(base[0])
                for i in hh:
                    P[tax].append(i)
    major = [i for i in set(P[2]+P[3]) if i not in set(P[4])]
    " in case of multiple bases "
    if len(major) > 1:
        cc = [(P[2]+P[3]).count(base) for base in major]
        major = major[cc.index(max(cc))]  ## maybe [0]
    elif len(major) == 1:
        major = major[0]
    else:
        major = [i for i in set(P[4]) if i in set(P[2]+P[3])][0]
    p1  = float(P[0].count(major))/len(P[0])
    p2  = float(P[1].count(major))/len(P[1])
    p3a = float(P[2].count(major))/len(P[2])
    p3b = float(P[3].count(major))/len(P[3])
    p3ab = float((P[2].count(major)+P[3].count(major))/(len(P[2])+len(P[3])))
    o   = float(P[4].count(major))/len(P[4])
    #print P,major
    return [p1,p2,p3a,p3b,p3ab,o]



def dstat5(BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA, pat):
    if pat[0] != pat[1]:
        if pat[4] == pat[3]:        ## BABAA, ABBAA
            if pat[3] != pat[2]:     # 01234  01234
                if pat[2] != pat[1]:
                    BABAA += 1
                else:
                    ABBAA += 1
        else:
            if pat[4] == pat[2]:      ## BAABA, ABABA
                if pat[3] == pat[1]:
                    ABABA += 1
                else:
                    BAABA += 1
            else:                     ## BABBA, ABBBA
                if pat[1] == pat[2]:
                    ABBBA += 1
                else:
                    BABBA += 1
    return [BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA]


def polyDstat5(BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA, patlist):
    ## calculate frequencies
    " look at the P3 taxon first for a derived allele "
    BABBA = ABBBA = BAABA = ABABA = BABAA = ABBAA = 0.0
    p1,p2,p3a,p3b,p3ab,o = makefreq(patlist)
    if p1+p2 != 0.0:
        if p3a != 0.0:
            if p3b != 0.0:
                "__BBA"
                ABBBA = ( (1.-p1)*p2*p3ab*(1.-o) )
                BABBA = ( p1*(1.-p2)*p3ab*(1.-o) )
            else:
                "__BAA"
                ABBAA = ( (1.-p1)*p2*p3a*(1.-p3b)*(1.-o) )
                BABAA = ( p1*(1.-p2)*p3a*(1.-p3b)*(1.-o) )
        else:
            if p3b != 0.0:
                "__ABA"
                ABABA = ( (1.-p1)*p2*(1.-p3a)*p3b*(1.-o) )
                BAABA = ( p1*(1.-p2)*(1.-p3a)*p3b*(1.-o) )
    dft12 = BABBA - ABBBA 
    dfb12 = BABBA + ABBBA
    dft1  = BABAA - ABBAA
    dfb1  = BABAA + ABBAA
    dft2  = BAABA - ABABA
    dfb2  = BAABA + ABABA
    return dft12,dfb12, dft2,dfb2, dft1,dfb1, BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA
    

def IUAfreq(Dft12,Dfb12,Dft1,Dfb1,Dft2,Dfb2,N,L):
    patlist = []
    BABBA = ABBBA = BAABA = ABABA = BABAA = ABBAA = 0
    k = N.transpose()
    names = k[0,]
    R = k[1:,]
    for site in R:
        p1 =  []
        p2 =  []
        p3a = []
        p3b = []
        o =   []
        if len(L[0]) > 1:
            for i in L[0]:
                p1.append(site[numpy.nonzero(names==i)])
        else:
            p1.append(site[numpy.nonzero(names==L[0])])
        p1 = numpy.concatenate(p1)

        if len(L[1])>1:
            for i in L[1]:
                p2.append(site[numpy.nonzero(names==i)])
        else:
            p2.append(site[numpy.nonzero(names==L[1])])
        p2 = numpy.concatenate(p2)
        
        if len(L[2])>1:
            for i in L[2]:
                p3a.append(site[numpy.nonzero(names==i)])
        else:
            p3a.append(site[numpy.nonzero(names==L[2])])
        p3a = numpy.concatenate(p3a)

        if len(L[3])>1:
            for i in L[3]:
                p3b.append(site[numpy.nonzero(names==i)])
        else:
            p3b.append(site[numpy.nonzero(names==L[3])])
        p3b = numpy.concatenate(p3b)

        if len(L[4])>1:
            for i in L[4]:
                o.append(site[numpy.nonzero(names==i)])
        else:
            o.append(site[numpy.nonzero(names==L[4])])
        o = numpy.concatenate(o)

        patlist = [p1,p2,p3a,p3b,o]
        if not any([all([i in ["N",'-'] for i in patlist[0]]),
                    all([i in ["N",'-'] for i in patlist[1]]),
                    all([i in ["N",'-'] for i in patlist[2]]),
                    all([i in ["N",'-'] for i in patlist[3]]),
                    all([i in ["N",'-'] for i in patlist[4]])]):
            if any([i not in patlist[4] for i in numpy.concatenate((patlist[2],patlist[3]))]):
                polyres = polyDstat5(BABBA,ABBBA,BAABA,ABABA,BABAA,ABBAA,patlist)
                dft12,dfb12, dft2,dfb2, dft1,dfb1, babba,abbba, baaba,ababa, babaa,abbaa = polyres
                BABBA += babba
                ABBBA += abbba
                BAABA += baaba
                ABABA += ababa
                BABAA += babaa
                ABBAA += abbaa
            else:
                dft12,dfb12, dft2,dfb2, dft1,dfb1 = [0.]*6
        else:
            dft12,dfb12, dft2,dfb2, dft1,dfb1 = [0.]*6
        Dft12 += dft12
        Dfb12 += dfb12
        Dft2  += dft2
        Dfb2  += dfb2
        Dft1  += dft1
        Dfb1  += dfb1
    return Dft12,Dfb12, Dft2,Dfb2, Dft1,Dfb1, BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA


def IUA(N,L):
    BABBA = ABBBA = BAABA = ABABA = BABAA = ABBAA = 0
    k = N.transpose()
    names = k[0,]
    R = k[1:,]
    for i in R:
        pat = [ i[numpy.nonzero(names==L[0])],
                i[numpy.nonzero(names==L[1])],
                i[numpy.nonzero(names==L[2])],
                i[numpy.nonzero(names==L[3])],
                i[numpy.nonzero(names==L[4])]]
        if all(i in list('ATGC') for i in pat):
            if len(set(pat[0][0]+pat[1][0]+pat[2][0]+pat[3][0]+pat[4][0])) == 2:
                BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA = dstat5(BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA,pat)
    return BABBA,ABBBA, BAABA,ABABA, BABAA,ABBAA



def bootfreq(D):
    which = iter(sample_wr(range(len(D)),len(D)))
    bootlist = []
    Dftop = Dfbot = 0
    while 1:
        try: d = which.next()
        except StopIteration: break
        if D[d]:
            a,b = D[d]
            Dftop += a
            Dfbot += b
    D = 0.
    if Dfbot > 0:
        D = Dftop/float(Dfbot)
    return D
    

def boot2(D):
    which = iter(sample_wr(range(len(D)),len(D)))
    bootlist = []
    ab__a = ba__a = 0
    while 1:
        try: d = which.next()
        except StopIteration: break
        if D[d]:
            a,b = D[d]
            ab__a += a
            ba__a += b
    D = 0.
    if ab__a+ba__a > 0:
        D = float(ab__a-ba__a)/float(ab__a+ba__a)
    return D


def runtest(infile,L,nboots,snpfreq, submitted):
    f = open(infile)
    k = iter(f)
    D12 = []
    D1 = []
    D2 = []
    tBABBA = tABBBA = tBAABA = tABABA = tBABAA = tABBAA = 0
    Dft12 = Dfb12 = Dft1 = Dfb1 = Dft2 = Dfb2 = 0
    while 1:
        ## measure counts by locus and save for bootstrapping
        P = {}
        try: d = k.next()
        except StopIteration: break
        while '//' not in d:
            a = d.split(" ")[0]
            b = d.strip().split(" ")[-1]
            if ">" in a:
                P[a.replace(">","")] = b.strip()
            d = k.next()
        if snpfreq:
            for tax in L:
                z = any([tax in P for tax in L[0]])
                y = any([tax in P for tax in L[1]])
                x = any([tax in P for tax in L[2]])
                w = any([tax in P for tax in L[3]])
                u = any([tax in P for tax in L[4]])
            if all([z,y,x,w,u]):
                N = numpy.array([[i]+list(P[i]) for i in P])
                dft12,dfb12, dft2,dfb2, dft1,dfb1, babba,abbba, baaba,ababa, babaa,abbaa = IUAfreq(Dft12,Dfb12,
                                                                                                   Dft1,Dfb1,
                                                                                                   Dft2,Dfb2,
                                                                                                   N,L)
                tBABBA += babba
                tABBBA += abbba
                tBAABA += baaba
                tABABA += ababa
                tBABAA += babaa
                tABBAA += abbaa
                D12.append([dft12,dfb12])
                D2.append( [dft2,dfb2])
                D1.append( [dft1,dfb1])
        else:
            if all(tax in P for tax in L):
                N = numpy.array([[i]+list(P[i]) for i in P])
                babba,abbba, baaba,ababa, babaa,abbaa = IUA(N,L)
                tBABBA += babba
                tABBBA += abbba
                tBAABA += baaba
                tABABA += ababa
                tBABAA += babaa
                tABBAA += abbaa
                D12.append([babba,abbba])
                D2.append( [baaba,ababa])
                D1.append( [babaa,abbaa])
    " calculate genome wide D "
    if snpfreq:
        D12_final = D2_final = D1_final = 0.
        dft_12 = sum([i[0] for i in D12])
        dbt_12 = sum([i[1] for i in D12])
        D12_final = 0.
        if dbt_12 > 0.:
            D12_final = dft_12/float(dbt_12)
        dft_2 = sum([i[0] for i in D2])
        dbt_2 = sum([i[1] for i in D2])
        D2_final = 0.
        if dbt_2 > 0.:
            D2_final = dft_2/float(dbt_2)
        dft_1 = sum([i[0] for i in D1])
        dbt_1 = sum([i[1] for i in D1])
        D1_final = 0.
        if dbt_1 > 0.:
            D1_final = dft_1/float(dbt_1)
        allDs = D12+D2+D1
        if len(allDs) > 0:
            pdisc = (float(len([i for i in allDs if any([j for j in i])])) / len(allDs))
        else:
            pdisc = 0.
    else:
        D12_final = D2_final = D1_final = 0.
        if tBABBA+tABBBA > 0:
            D12_final = (tBABBA-tABBBA)/float(tBABBA+tABBBA)
        if tBAABA+tABABA > 0:
            D2_final =  (tBAABA-tABABA)/float(tBAABA+tABABA)
        if tBABAA+tABBAA > 0:
            D1_final =  (tBABAA-tABBAA)/float(tBABAA+tABBAA)
        if len(D12+D1+D2) > 0.:
            pdisc = (float(len([i for i in D12+D1+D2 if any([j for j in i])])) / len(D12+D1+D2))
        else:
            pdisc = 0.
    " bootstrapping "
    B12 = []
    B1 = []
    B2 = []
    for i in range(nboots):
        if snpfreq:
            b12 = bootfreq(D12)
            b1  = bootfreq(D1)
            b2  = bootfreq(D2)
        else:
            b12 = boot2(D12)
            b1  = boot2(D1)
            b2  = boot2(D2)
        B12.append(b12)
        B1.append(b1)
        B2.append(b2)
    STD12 = numpy.std(B12)
    STD1  = numpy.std(B1)
    STD2  = numpy.std(B2)
    " final calculation "
    if STD12 > 0:
        Z12 = (abs(D12_final/STD12))
    else: Z12 = 0.
    if STD1 > 0:
        Z1 =  (abs(D1_final/STD1))
    else: Z1 = 0.
    if STD2 > 0:
        Z2 =  (abs(D2_final/STD2))
    else: Z2 = 0.
    return [L,D12_final,Z12,
            D1_final,Z1,
            D2_final,Z2,
            tBABBA,tABBBA,
            tBABAA,tABBAA,
            tBAABA,tABABA,
            len(D1),pdisc, submitted]
            

def checktaxa(taxalist,alignfile):
    with open(alignfile) as infile:
        data = infile.readlines()
    taxainfile = set()
    for line in data:
        if ">" in line:
            tax = line.split(" ")[0].replace(">","")
            if tax not in taxainfile:
                taxainfile.add(tax)
    if not set(taxainfile).difference(taxainfile):
        return 1


def main(tests, alignfile, nboots, nproc):
    import sys
    print >>sys.stdout, "\t".join([ 'D_12','D_1','D_2',
                                    'Z_12','Z_1','Z_2  |',
                                    'BABBA','ABBBA |',
                                    'BABAA','ABBAA |',
                                    'BAABA','ABABA |',
                                    'nloci','pdisc',
                                    'p1','p2','p3_1','p3_2','O','notes'])
    print >>sys.stdout, "-"*150 ##"-"*63+"="*21+'-'*50

    work_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()
    submitted = 0
    Notes = []
    for rep in tests:
        notes = ""
        if len(rep) == 2:
            rep,notes = rep
        p1,p2,p3a,p3b,o = rep
        if all(["[" in i for i in rep[1:]]):
            p1  = p1[1:-1].split(",")
            p2  = p2[1:-1].split(",")
            p3a = p3a[1:-1].split(",")
            p3b = p3b[1:-1].split(",")
            o   = o[1:-1].split(",")
            if checktaxa([p1,p2,p3a,p3b,o],alignfile):
                work_queue.put([alignfile, [p1,p2,p3a,p3b,o], nboots, 1, submitted])
                submitted += 1
        else:
            if checktaxa([p1,p2,p3a,p3b,o],alignfile):
                work_queue.put([alignfile, [p1,p2,p3a,p3b,o], nboots, 0, submitted])
                submitted += 1
        Notes.append(notes)

    jobs = []
    for i in range(min(submitted,nproc)):
        worker = Worker(work_queue, result_queue, runtest)
        jobs.append(worker)
        worker.start()
    for j in jobs:
        j.join()

    Results = [result_queue.get() for i in range(submitted)]
    Results.sort(key = lambda x:x[8])
    for i in range(len(Results)):
        L,D12_final,Z12,D1_final,Z1,D2_final,Z2,tBABBA,tABBBA,tBABAA,tABBAA,tBAABA,tABABA,nloc,pdisc,sub = Results[i]
        print >>sys.stdout, "\t".join(map(str,[`round(D12_final,3)`[0:6],
                                               `round(D1_final,3)`[0:6],
                                               `round(D2_final,3)`[0:6],
                                               `round(Z12,3)`[0:5],
                                               `round(Z1,3)`[0:5],
                                               `round(Z2,3)`[0:5],
                                               `tBABBA`[0:5],`tABBBA`[0:5],
                                               `tBABAA`[0:5],`tABBAA`[0:5],
                                               `tBAABA`[0:5],`tABABA`[0:5],
                                               nloc,`round(pdisc,3)`[0:5],
                                               L[0],L[1],L[2],L[3],L[4],Notes[i]]))

        # if D12_final >= 0:
        #     print >>sys.stdout, "\t".join(map(str,[`round(D12_final*-1,3)`[0:6],
        #                                            `round(D1_final*-1,3)`[0:6],
        #                                            `round(D2_final*-1,3)`[0:6],
        #                                            `round(Z12,3)`[0:5],
        #                                            `round(Z1,3)`[0:5],
        #                                            `round(Z2,3)`[0:5],
        #                                            `tABBBA`[0:5],`tBABBA`[0:5],
        #                                            `tABBAA`[0:5],`tBABAA`[0:5],
        #                                            `tABABA`[0:5],`tBAABA`[0:5],
        #                                            nloc,`round(pdisc,3)`[0:5],notes,
        #                                            L[1],L[0],L[2],L[3],L[4]]))
        # else:
        #     print >>sys.stdout, "\t".join(map(str,[`round(D12_final,3)`[0:6],
        #                                            `round(D1_final,3)`[0:6],
        #                                            `round(D2_final,3)`[0:6],
        #                                            `round(Z12,3)`[0:5],
        #                                            `round(Z1,3)`[0:5],
        #                                            `round(Z2,3)`[0:5],
        #                                            `tBABBA`[0:5],`tABBBA`[0:5],
        #                                            `tBABAA`[0:5],`tABBAA`[0:5],
        #                                            `tBAABA`[0:5],`tABABA`[0:5],
        #                                            nloc,`round(pdisc,3)`[0:5],notes,
        #                                            L[0],L[1],L[2],L[3],L[4]]))



if __name__ == '__main__':
    main()




