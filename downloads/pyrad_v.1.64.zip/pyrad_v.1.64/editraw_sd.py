import multiprocessing
import itertools
import sys
import os
import glob
import subprocess
import operator
from potpour import Worker


def readtech(name):
    ## determines illumina technology from read names
    ## need to add more options for other types...
    if "#" in name:
        xy = ":".join(name.split(":")[1:5]).replace("#0/1","")
        offset = 64
    else:
        xy = ":".join(name.split(":")[4:7]).replace(" ",":")
        offset = 33
    return xy, offset


def revcomp(s):
    ss = s[::-1].strip().replace("A","t").replace("T","a").\
         replace("C","g").replace("G","c").upper()
    return ss


def barcode(handle,Bcode):
    B = {}
    data = open(Bcode).readlines()
    for line in data:
        if line.strip():
            a,b = line.strip().split("\t")
            B[a] = b
    return B[handle].upper()


def rawedit(infile,CUT,trimkeep,matchpairs,Bcode,pN,minlen,radgbs,strict,Q,WORK,stripped):
    """prunes barcode and restriction site
    replaces calls if Q score too low """
    f = open(infile,'r')
    n = str(infile.split('/')[-1].replace("."+infile.split(".")[-1],''))
    k = itertools.izip(*[iter(f)]*4)
    writing_r = []
    writing_c = []
    orig = keep = keepcut = pair = 0
    handle = WORK+'edits/'+str(n)+".edit"
    if "," in CUT:
        CUT1,CUT2 = CUT.strip().split(",")
    else:
        CUT1 = CUT2 = CUT
    while 1:
        try: d = k.next()
        except StopIteration: break
        if matchpairs:
            orig += 2
        else:
            orig += 1
        SS = d[1].strip()
        "is CUT in Bcode?"
        cnt = SS[:16].count(CUT1)
        if cnt == 2:
            before = len(CUT1.join(SS.split(CUT1)[0:2]))+len(CUT1)
        else:
            before = len(SS.split(CUT1)[0])+len(CUT1)
        if not stripped:
            if matchpairs:
                ph = map(ord,d[3][before:].strip().replace("*","z"))
            else:
                ph = map(ord,d[3][before:].strip())
        else:
            if matchpairs:
                ph = map(ord,d[3].strip().replace("*","z"))
            else:
                ph = map(ord,d[3].strip())
        xy, offset = readtech(d[0])
        phred = map(lambda x:x-offset,ph)
        seq = ["N"]*len(phred)
        if not stripped:
            for base in range(len(phred)):
                if phred[base] >= Q:            ## quality threshold
                    seq[base] = SS[before:][base]

                    ##try: seq[base] = SS[before:][base]
                    ##except IndexError:
                    ##    print "len error in seq", d[0], 'skipping'
        else:
            for base in range(len(phred)):
                if phred[base] >= Q:       
                    seq[base] = SS[base]
            

        " if n seqs divisible by 5000 write out results to file" 
        if not orig % 5000:
            if (trimkeep or matchpairs):
                if trimkeep:
                    " write separately"
                    with open(WORK+'edits/'+str(n)+".editC",'a') as outfile_c:
                        outfile_c.write("".join([z for z in writing_c]))
                    with open(WORK+'edits/'+str(n)+".editR",'a') as outfile:
                        outfile.write("".join([z for z in writing_r]))
                else:
                    with open(WORK+'edits/'+str(n)+".editR",'a') as outfile:
                        outfile.write("".join([z for z in writing_r]))
                        outfile.write("".join([z for z in writing_c]))
            else:
                with open(WORK+'edits/'+str(n)+".edit",'a') as outfile:
                    outfile.write("".join([z for z in writing_r]))
            writing_r = []
            writing_c = []
            
    
        if matchpairs:
            s1, s2 = ("".join(seq)).split("**")
            s2 = s2[max(0,len(Bcode)-1):-(len(CUT2)+1)]
            """ if rev complement of cut in s1, or cut is s2, then
            reads may have overlapped. look for CUT+adapter and trim.
            record that tags may haveT overlapped with '_c' tag. """
            if strict:
                if strict==2:
                    lookfor = revcomp(CUT1)
                    lookfor2 = CUT2
                else:
                    lookfor = revcomp(CUT1)+"A"
                    lookfor2 = Bcode[-3:]+CUT2
                try: wheretocut1 = s1.rindex(lookfor)
                except ValueError:
                    try: wheretocut1 = s1.rindex("AGATCG")-(len(CUT1))  ## adapter, in case error in CUT
                    except ValueError:
                        try: wheretocut1 = s1.rindex("AAATCG")-(len(CUT1))  ## adapter, in case error in CUT
                        except ValueError:
                            try: wheretocut1 = s1.rindex("TCGCAGG")-(len(CUT1))-3  ## adapter, in case error in CUT
                            except ValueError:
                                try: wheretocut1 = s1.rindex("TCGGAAG")-(len(CUT1))-3  ## adapter, in case error in CUT
                                except ValueError:
                                    wheretocut1 = None
                try: wheretocut2 = s2.index(lookfor)+len(lookfor)
                except ValueError:
                    try: wheretocut2 = s2.index("CCGATCT")+7+len(CUT2)+len(Bcode)  ## adapter, in case error in CUT
                    except ValueError:
                        try: wheretocut2 = s2.index("CCGATCT")+7+len(CUT2)+len(Bcode)  ## adapter, in case error in CUT
                        except ValueError:
                            try: wheretocut2 = s2.index("CTTCCGA")+10+len(CUT2)+len(Bcode)  ## adapter, in case error in CUT
                            except ValueError:
                                wheretocut2 = None
            else:
                wheretocut1 = wheretocut2 = None

            if wheretocut1:
                if wheretocut2:
                    s1 = s1[:wheretocut1]
                    s2 = s2[wheretocut2:]
                else:
                    s1 = s1[:wheretocut1]
                    s2 = s2[-(wheretocut1+1):-1]
            else:
                if wheretocut2:
                    s1 = s1[:-wheretocut2]
                    s2 = s2[wheretocut2:]

            if (wheretocut1 or wheretocut2):
                pair += 1
                if s1.count("N") <= pN:   
                    if len(s1) > minlen:
                        if revcomp(CUT1) not in s1:
                            writing_c.append(">"+n+"_"+str(pair)+'_c1'+'\n'+s1+"\n")
                            keepcut += 1
                            #keep += 1
                if s2.count("N") <= pN: 
                    if len(s2) > minlen:
                        #if revcomp(CUT2) not in s2:
                        if CUT2 not in s2:
                            writing_c.append(">"+n+"_"+str(pair)+'_c2'+'\n'+s2+"\n")
                            keepcut += 1
                            #keep += 1
            else:
                ## reads do not appear to have overlapped, but still may overlap
                ## slightly. record with '_r' tag.
                ## both are recorded as the same 'keep' id number, 
                ## but adds two to the 'keep' counter
                pair += 1
                if s1.count("N") <= pN: 
                    if len(s1) > minlen:
                        writing_r.append(">"+n+"_"+str(pair)+"_r1"+"\n"+s1+"\n")
                        keep += 1
                if s2.count("N") <= pN: 
                    if len(s2) > minlen:
                        writing_r.append(">"+n+"_"+str(pair)+"_r2"+"\n"+s2+"\n")
                        keep += 1


        else:
            " not paired-end reads "
            s = "".join(seq)
            wheretocut1 = None
            if strict:
                if radgbs:
                    if strict == 2:
                        lookfor = revcomp(CUT)
                    else: 
                        lookfor = revcomp(CUT)+"A"
                else:
                    lookfor = revcomp(CUT)+"AGAT"
                try: wheretocut1 = s.rindex(lookfor)
                except ValueError:
                    if radgbs:
                        lookfor = "AGATCG"
                    else:
                        lookfor = "AGATCGGA" 
                    try: wheretocut1 = s.rindex(lookfor)-(len(CUT)+1)  ## adapter, in case error in CUT
                    except ValueError:
                        wheretocut1 = None
            s = s[:wheretocut1]

            if strict:
                palincheck  = "AGCAGAGCT"
            else:
                palincheck = "T"*200
            if palincheck not in s:     ## palindromic adapter sequence segment
                if s.count("N") <= pN:   ## max allowed Ns
                    if len(s) >= minlen:   ## if read is trimmed, must be minlen long
                        if wheretocut1:     ## if it was trimmed...
                            if revcomp(CUT) not in s:   ## one final check for the CUT site
                                writing_c.append(">"+n+"_"+str(keep)+"_c1"+"\n"+s+"\n")
                                #keep += 1
                                keepcut += 1
                        else:
                            writing_r.append(">"+n+"_"+str(keep)+"_r1"+"\n"+s+"\n")
                            keep += 1

    if (trimkeep or matchpairs):
        if trimkeep:
            " write separately"
            with open(WORK+'edits/'+str(n)+".editC",'a') as outfile_c:
                outfile_c.write("".join([z for z in writing_c]))
            with open(WORK+'edits/'+str(n)+".editR",'a') as outfile:
                outfile.write("".join([z for z in writing_r]))
        else:
            with open(WORK+'edits/'+str(n)+".editR",'a') as outfile:
                outfile.write("".join([z for z in writing_r]))
                outfile.write("".join([z for z in writing_c]))
    else:
        with open(WORK+'edits/'+str(n)+".edit",'a') as outfile:
            outfile.write("".join([z for z in writing_r]))
    writing_r = []
    writing_c = []

    f.close()
    sys.stderr.write(".")
    return [handle.split("/")[-1].replace(".edit",""),str(orig),str(keep),str(keepcut)]



def main(Parallel, CUT, GLOB, trimkeep, matchpairs, Bcode, pN, minlen, radgbs, strict, Q, WORK, stripped):
    print >>sys.stderr, "\tstep 2: editing raw reads \n\t",

    # create output directories
    if not os.path.exists(WORK+'stats'):
        os.makedirs(WORK+'stats')
    if not os.path.exists(WORK+'edits'):
        os.makedirs(WORK+'edits')

    lookfor = ".edit"
    if matchpairs: lookfor += "R"
    if stripped:
        print 'barcodes already stripped'
    # load up work queue
    submitted = 0
    work_queue = multiprocessing.Queue()
    if len(glob.glob(GLOB)) > 1:
        FS = [f for f in glob.glob(GLOB)]
        # order files by size
        for i in range(len(FS)):
            statinfo = os.stat(FS[i])
            FS[i] = FS[i],statinfo.st_size
        FS.sort(key=operator.itemgetter(1))
        FS = [i[0] for i in FS][::-1]
        # submit jobs to queue
        for handle in FS:
            if matchpairs:
                if not stripped:
                    bcode = barcode(handle.split("/")[-1].replace(".fq","").replace(".fastq",""),Bcode)
                else:
                    bcode = ""
            else:
                bcode = ""
            if WORK+'edits/'+handle.split("/")[-1].replace(".fq",lookfor).replace(".fastq",lookfor) not in glob.glob(WORK+"edits/*"):
                if os.stat(handle).st_size > 0:   ## exclude empty files
                    work_queue.put([handle,CUT,trimkeep,matchpairs,bcode,float(pN),minlen,radgbs,strict,Q, WORK, stripped])
                    submitted += 1
            else:
                print handle.split("/")[-1].replace(".fq",lookfor).replace(".fastq",lookfor)+" already in edits/"

    else:
        if matchpairs:
            if not stripped:
                bcode = barcode(glob.glob(GLOB)[0].split("/")[-1].replace(".fq","").replace(".fastq",""),Bcode)
            else:
                bcode = ""
        else:
            bcode = ""
        handle = glob.glob(GLOB)[0]
        if WORK+'edits/'+handle.split("/")[-1].replace(".fq",lookfor).replace(".fastq",lookfor) not in glob.glob(WORK+"edits/*"):
            print WORK+'edits/'+handle.split("/")[-1].replace(".fq",lookfor).replace(".fastq",lookfor)
            try: work_queue.put([handle,CUT,trimkeep,matchpairs,bcode,float(pN),minlen,radgbs,strict,Q, WORK, stripped])
            except IndexError:
                print "\n\tno files found\n, check lines 2 or 18 of params file"
                sys.exit()
            submitted = 1
        else:
            print 'skipping',handle.split("/")[-1].replace(".fq",lookfor).replace(".fastq",lookfor)+", already in edits/"
            sys.exit()

    # create a queue to pass to workers to store the results
    result_queue = multiprocessing.Queue()

    # spawn workers, give function
    jobs = []
    for i in range( min(Parallel,submitted) ):
        worker = Worker(work_queue, result_queue, rawedit)
        worker.start()
        jobs.append(worker)
    for job in jobs:
        job.join()

    # collect the results off the queue
    outstats = open(WORK+"stats/s2.rawedit.txt",'a')
    print >> outstats, "\t".join(["sample","Nreads","pass.full","pass.trim","pass.total"])
    for i in range(submitted):
        a,b,c,d = result_queue.get()
        #if trimkeep:
        print >> outstats, "\t".join([a,b,c,d,str(int(c)+int(d))])
        #else:
        #    print >> outstats, "\t".join([a,b,c,'0',c])

    print >>outstats, """
    Nreads = total number of reads for a sample
    pass.full = reads that passed quality filtering at full length
    pass.trim = reads that passed quality filtering but were trimmed due to detection of restriction site
    pass.total = pass.full + pass.trim
    note: you can set minimum length of kept trimmed reads on line 39 of the params file
    note: you can set option on line 38 to analyze trimmed reads separately. """
    outstats.close()

