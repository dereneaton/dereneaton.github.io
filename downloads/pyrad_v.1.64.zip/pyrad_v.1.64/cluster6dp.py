#! /usr/bin/env python
import multiprocessing
import sys
import os
import numpy
import itertools
import glob
import subprocess
import operator
from itertools import izip
from potpour import Worker
import time


def makederepclust(outfolder,handle,max_inserts):
    Userout = open(outfolder+"/"+handle.split("/")[-1].replace(".edit",".u"), 'r').readlines()
    outfile = open(outfolder+"/"+handle.split("/")[-1].replace(".edit",".clust"),'w')
    " load .edit file into a Dic"
    D = {}
    f = open(handle.replace(".edit",".derep")).read()
    for line in f.split(">")[1:]:
        a,b,c = line.replace("\n","").split(";")
        D[">"+a+";"+b+";"] = [int(b.replace("size=","")),c.strip()]
    U = {}

    for line in [line.split("\t") for line in Userout]:
        if ">"+line[1] in U:
            U[">"+line[1]].append([">"+line[0],line[4],line[5].strip(),line[3]])
        else:
            U[">"+line[1]] = [[">"+line[0],line[4],line[5].strip(),line[3]]]

    " map sequences to clust file in order"
    seq = ""
    for key,values in U.items():
        seq = key+"\n"+D[key][1]+'\n'
        S    = [i[0] for i in values]  ## names of matches
        R    = [i[1] for i in values]  ## + or - for strands
        Cov  = [int(i[2]) for i in values]  ## query coverage
        ins = [i[3] for i in values]
        " allow only 'max_inserts' # of indels"
        if not any([int(i) > max_inserts for i in ins]):
            for i in range(len(S)):
                if R[i] == "+":
                    seq += S[i]+'+\n' + D[S[i]][1] + "\n"
                else:
                    seq += S[i]+'-\n' + comp(D[S[i]][1][::-1]) + "\n"
        seq += "//\n//\n"
        print >>outfile, seq.strip()

    " make Dict. from _temp file"
    I = {}
    with open(outfolder+"/"+handle.split("/")[-1].replace(".edit","._temp"),'r') as invar:
        A = [(">"+i.replace("\n","")).split(';') for i in invar.read().split(">")[1:]]
    for i in A:
        try: I[i[0]+';'+i[1]+';'] = i[2]
        except IndexError:
            None  ## skip binary errors 
    del A

    " create a set for keys in I not in U"
    set1 = set(I.keys())
    set2 = set(U.keys())
    diff = set1.difference(set2)
    if len(diff) > 1:
        for i in diff:
            seq = i+'\n'+I[i].upper()+"\n"+"//\n//\n"
            print >>outfile, seq.strip()
    else:
        if diff:
            pp = diff.pop()
            print >>outfile, pp+'\n'+I[pp].upper().strip()+"\n"+"//\n//\n"
    outfile.close()
    del f
    del Userout



def derep(UCLUST, handle, radgbs, minlen):
    C = " -derep_fulllength "+handle
    if radgbs:
        P = " -strand both "
    else:
        P = " "
    M = ""
    #M = " -minuniquesize 2 "
    cmd = UCLUST+\
        C+\
        P+\
        M+\
        " -output "+handle.replace(".edit",".step")+\
        " -sizeout "+\
        " -minseqlength "+str(minlen)+\
        " -quiet"+\
        " -threads 1"
    subprocess.call(cmd, shell=True)



def sortbysize(UCLUST, handle):
    cmd = UCLUST+\
          " -sortbysize "+handle.replace(".edit",".step")+\
          " -output "+handle.replace(".edit",".derep")+\
          " -quiet "
    subprocess.call(cmd, shell=True)
    cmd2 = "rm "+handle.replace(".edit",".step")
    subprocess.call(cmd2, shell=True)



def splitbigfilesforderep(FS,UCLUST,radgbs,minlen):
    """ work around 4GB limit of 32-bit usearch
    by splitting files for derep then rejoining """
    for handle in FS:
        bsize = 5000000
        statinfo = os.stat(handle)
        size = statinfo.st_size
        if size > 250000000:
            infile = open(handle,'r')
            L = infile.readlines()
            infile.close()
            breaks = len(L)/bsize
            l = 0
            if breaks > 1:
                for b in range(breaks+1):
                    with open(handle+"_piece_"+str(b),'w') as out:
                        out.write("".join(L[l:l+bsize]))
                    derep(UCLUST,handle+"_piece_"+str(b),radgbs,minlen)
                    l += bsize
            else:
                b=0
                with open(handle+"_piece_"+str(b),'w') as out:
                    out.write("".join(L[l:l+bsize]))
                derep(UCLUST,handle+"_piece_"+str(b),radgbs,minlen)
                l += bsize
            with open(handle+"_piece_"+str(b+1),'w') as out:
                out.write("".join(L[l:]))
            derep(UCLUST, handle+"_piece_"+str(b+1), radgbs, minlen)
            cmd = "cat "+handle.replace(".edit",".step")+"_piece* > "+handle.replace(".edit",".derep")
            os.system(cmd)
            cmd = "rm "+handle.replace(".edit",".step")+"_piece*"
            os.system(cmd)
            if os.path.exists(handle+"_piece_0"):
                cmd = "rm "+handle+"_piece*"
                os.system(cmd)



def fullcluster(UCLUST, outfolder, handle, wclust, Parallel, radgbs, fileno, complementmatch):
    C = " -cluster_smallmem "+handle.replace(".edit",".derep")
    if ".derepC" in C:
        COV = " -query_cov .90 -target_cov .90 "
    else:
        COV = " -query_cov "+str(complementmatch)+" -target_cov "+str(complementmatch)
    if radgbs:
        P = " -strand both "
        COV = " -query_cov "+str(complementmatch)
    else:
        P = " -leftjust "
        #P = ""
        COV = " -query_cov .90"
    cmd = UCLUST+\
        C+\
        P+\
        COV+\
        " -id "+wclust+\
        " -userout "+outfolder+"/"+handle.split("/")[-1].replace(".edit",".u")+\
        " -userfields query+target+id+gaps+qstrand+qcov"+\
        " -maxaccepts 1"+\
        " -maxrejects 0"+\
        " -minsl 0.5"+\
        " -fulldp"+\
        " -usersort "+\
        " -notmatched "+outfolder+"/"+handle.split("/")[-1].replace(".edit","._temp")+\
        " -quiet"
        #" -gapopen 10.0I/0.0E -gapext 10.0I/0.0E"
    subprocess.call(cmd, shell=True)



def stats(outfolder, handle, mindepth):
    temphandle = outfolder+"/"+handle.split("/")[-1].replace(".edit",".clust")
    infile = open(temphandle)
    L = itertools.izip(*[iter(infile)]*2)
    a = L.next()[0]
    depth = []
    d = int(a.split(";")[1].replace("size=",""))
    while 1:
        try: a = L.next()[0]
        except StopIteration: break
        if a != "//\n":
            d += int(a.split(";")[1].replace("size=",""))
        else:
            depth.append(d)
            d = 0
    infile.close()
    keep = [i for i in depth if i>=(mindepth)]
    namecheck = temphandle.split("/")[-1].replace(".clust","")
    if depth:
        me = round(numpy.mean(depth),3)
        std = round(numpy.std(depth),3)
    else:
        me = std = 0.0
    if keep:
        mek = round(numpy.mean(keep),3)
        stdk = round(numpy.std(keep),3)
    else:
        mek = stdk = 0.0
    out = [namecheck,
           len(depth),
           me, std,
           len(keep),
           mek,stdk]
    sys.stderr.write("\t"+handle.split("/")[-1]+" "+"finished, "+str(len(depth))+"loci\n")
    return out


def comp(seq):
    return seq.replace("A",'t')\
           .replace('T','a')\
           .replace('C','g')\
           .replace('G','c')\
           .upper()


def sortalign(stringnames):
    G = stringnames.split("\n>")
    GG = [i.split("\n")[0].replace(">","")+"\n"+"".join(i.split('\n')[1:]) for i in G]
    aligned = [i.split("\n") for i in GG]
    nn = [">"+i[0] for i in aligned]    #+["//"] #[">"+aligned[0][0]]
    seqs = [i[1] for i in aligned]      #+["//"]   #[aligned[0][1]]
    return nn,seqs


def alignfast(names,seqs,muscle):
    ST = "\n".join('>'+i+'\n'+j for i,j in zip(names,seqs))
    cmd = "echo '"+ST+"' | "+muscle+" -gapopen -800 -quiet -in -"
    p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    (fin, fout) = (p.stdin, p.stdout)
    return fout.read()


def align(infile,mindepth,muscle):
    ### for each cluster make muscle input, without repeat seq
    f = open(infile)
    outfile = open(infile.replace(".clust",".clustS"),'w')
    k = itertools.izip(*[iter(f)]*2)
    while 1:
        try: first = k.next()
        except StopIteration: break
        itera = [first[0],first[1]]
        names = []    #itera[0].strip()]
        seqs = []     #itera[1].strip()]
        while itera[0] != "//\n":
            names.append(itera[0].strip())
            seqs.append(itera[1].strip())
            itera = k.next()
        if len(names) > 1:     #mindepth-1:
            names, seqs = orderseqs(names,seqs)
            ## keep only the 200 most replicated reads, aligning more is problematic
            stringnames = alignfast(names[0:200],seqs[0:200],muscle)
            nn, seqs = sortalign(stringnames)
            nn, seqs = orderseqs(nn,seqs)
            nn += ["//"]
            seqs += ["//"]
            outfile.write("\n".join(['\n'.join(i) for i in zip(nn,seqs)])+"\n")
        else:
            outfile.write(names[0]+'\n'+seqs[0]+'\n//\n//\n')
    outfile.close()


def orderseqs(nn,seqs):
    try: dereps = [int(i.split(";")[1].replace("size=","")) for i in nn]
    except IndexError:
        print nn
    ordered = sorted(range(len(dereps)), key=lambda a: dereps[a], reverse=True)
    nnames = []
    sseqs = []
    for i in ordered:
        nnames.append(nn[i])
        sseqs.append(seqs[i])
    return nnames, sseqs



def final(UCLUST, outfolder, handle, wclust, mindepth, Parallel, muscle, radgbs, fileno, minlen, max_inserts, complementmatch, WORK):
    if handle.replace(".edit",".derep") not in glob.glob(WORK+"edits/*"):
        derep(UCLUST, handle, radgbs, minlen)
        sortbysize(UCLUST,handle)
    fullcluster(UCLUST, outfolder, handle, wclust, Parallel, radgbs, fileno, complementmatch)
    makederepclust(outfolder, handle, max_inserts)
    align(outfolder+"/"+handle.split("/")[-1].replace(".edit",".clust"), mindepth, muscle)
    return stats(outfolder, handle, mindepth)



def cmd_exists(cmd):
    return subprocess.call("type " + cmd, shell=True, 
        stdout=subprocess.PIPE, stderr=subprocess.PIPE) == 0


def main(Parallel, wclust, mindepth, UCLUST, trimkeep,
         subset, radgbs, muscle, minlen, max_inserts,
         complementmatch, WORK):


    " find usearch"
    if not cmd_exists(UCLUST):
        print "\tcannot find usearch, edit path in input file"
        sys.exit()

    " find muscle"
    if not cmd_exists(muscle):
        print "\tcannot find muscle, edit path in input file"
        sys.exit()

    " find .edit files in edits/ directory "
    if not os.path.exists(WORK+'edits/'):
        print "\terror: could not find edits/ folder in working directory"
        sys.exit()

    " make output folder for clusters" 
    if not os.path.exists(WORK+'clust'+wclust):
        os.makedirs(WORK+'clust'+wclust)
    outfolder = WORK+'clust'+str(wclust)

    FS = []
    " option to exclude trimmed sequences"
    if len(glob.glob(WORK+"edits/"+subset+"*.edit*")) > 1:  # if not 1 sample
        for f in glob.glob(WORK+"edits/"+subset+"*.edit*"):
            if not os.path.exists(outfolder+"/"+f.replace(".edit",".clustS")):
                size = os.stat(f)
                if size.st_size > 0:
                    FS.append(f)
            else:
                print outfolder+"/"+f.replace(".edit",".clustS")+" already exists"
        " arranges files by decreasing size"
        for i in range(len(FS)):
            statinfo = os.stat(FS[i])
            FS[i] = FS[i],statinfo.st_size
        FS.sort(key=operator.itemgetter(1))
        FS = [i[0] for i in FS][::-1]
    else:
        FS = glob.glob(WORK+"edits/"+subset+"*.edit*")

    
    sys.stderr.write("\n\tde-replicating files for clustering...\n")

    " do not split big files if using 64-bit usearch, else..."
    if "64" not in UCLUST:
        splitbigfilesforderep(FS,UCLUST,radgbs,minlen)

    " load work queue"
    work_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()

    " check if clust files exist, otherwise perform function 'final' on them"
    submitted = {}
    fileno = 1
    sys.stderr.write("\n\tstep 3: within-sample clustering of "+\
                     `len(FS)`+" samples at "+`wclust`+\
                     " similarity using up to "+`Parallel`+" processors\n")

    for handle in FS:
        if outfolder+"/"+handle.split("/")[-1].replace(".edit",".clustS") not in glob.glob(outfolder+"/*"):
            work_queue.put([UCLUST,outfolder,handle,wclust,mindepth,
                            Parallel,muscle,radgbs,fileno, minlen,
                            max_inserts,complementmatch,WORK])
            submitted[handle] = 1
        else:
            print "\tskipping"+outfolder+"/"+handle.split("/")[-1].replace(".edit",".clustS")+\
                  ' already exists in '+outfolder+"/"

    " create a queue to pass to workers to store the results"
    jobs = []
    for i in range( min(submitted,Parallel) ):
        worker = Worker(work_queue, result_queue, final)
        jobs.append(worker)
        worker.start()
    for j in jobs:
        j.join()

    " output statistics on depth of coverage"
    outstats = open(WORK+"stats/s3.clusters.txt",'a')
    print >>outstats, '\n'+'\t'.join(['taxa','total','dpt.me',\
                                 'dpt.sd','d>'+`mindepth-1`+'.tot',\
                                 'd>'+`mindepth-1`+'.me',\
                                 'd>'+`mindepth-1`+'.sd'])
    while not result_queue.empty():
        print >> outstats, "\t".join(map(str,result_queue.get()))
    print >>outstats, """
    ## total = total number of clusters, including singletons
    ## dpt.me = mean depth of clusters
    ## dpt.sd = standard deviation of cluster depth
    ## >N.tot = number of clusters with depth greater than N
    ## >N.me = mean depth of clusters with depth greater than N
    ## >N.sd = standard deviation of cluster depth for clusters with depth greater than N
    """
    outstats.close()
    for handle in FS:
        nothere = 0
        try: submitted[handle]
        except KeyError:
            nothere = 1
        if not nothere:
            if submitted[handle]:
                cmd = "rm "+outfolder+"/"+handle.split("/")[-1].replace(".edit",".clust")
                subprocess.call(cmd, shell=True)




