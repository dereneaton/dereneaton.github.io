#!/usr/bin/python

import itertools
import sys
import glob
import os
import multiprocessing
from potpour import Worker


def combinefiles(GLOB):
    "combines first and second reads file names"
    if len(glob.glob(GLOB)) > 1:
        FS = [f for f in glob.glob(GLOB)]
    else:
        FS = glob.glob(GLOB)
    firsts = [i.split("R1_") for i in FS if len(i.split("R1_"))>1]
    seconds = [i.split("R2_") for i in FS if len(i.split("R2_"))>1]
    if len(firsts) != len(seconds):
        raise Exception("different numbers of first and second read files.\
              Check that the names of files are correct")
    JOBS = []
    for num in range(1,len(firsts)+1):
        if num < 10:
            r1 = "R1_".join([r for r in firsts if "00"+`num` in r[1].split(".fastq")[0]][0])
            r2 = "R2_".join([r for r in seconds if "00"+`num` in r[1].split(".fastq")[0]][0])
        elif (num >9 and num < 100):
            r1 = "R1_".join([r for r in firsts if "0"+`num` in r[1].split(".fastq")[0]][0])
            r2 = "R2_".join([r for r in seconds if "0"+`num` in r[1].split(".fastq")[0]][0])
        else:
            r1 = "R1_".join([r for r in firsts if `num` in r[1].split(".fastq")[0]][0])
            r2 = "R2_".join([r for r in seconds if `num` in r[1].split(".fastq")[0]][0])
        JOBS.append([r1,r2])
    return JOBS


def revcomp(s):
    "returns reverse complement of a string"
    ss = s[::-1].strip().replace("A","t").replace("T","a").\
         replace("C","g").replace("G","c").upper()
    return ss


def barmatch(C, Raws, CUT, matchpairs, num, maxmismatch, WORK):
    """matches reads to barcodes in barcode file
    and writes to individual temp files, after all
    read files have been split, temp files are collated
    into .fq files"""
    
    locus = 0
    Quality = 0
    match = 0

    "read in paired end read files"
    if matchpairs:
        fr1 = open(Raws[0])
        fr2 = open(Raws[1])
        R1 = itertools.izip(*[iter(fr1)]*4)
        R2 = itertools.izip(*[iter(fr2)]*4)
    else:
        "read in single end read file"
        fr1 = open(Raws)
        R1 = itertools.izip(*[iter(fr1)]*4)

    D = {}
    while 1:
        try: r1 = R1.next()
        except StopIteration: break

        "match paired end reads together"
        if matchpairs:
            r2 = R2.next()
            z = zip(r1,r2)
            l = [z[0][0].strip(),\
                 "**".join([z[1][0].strip(), revcomp(z[1][1])]),\
                 z[2][0].strip(),\
                 "**".join([z[3][0].strip(),z[3][1][::-1].strip()])]
        else:
            "make list of four fastq line elements"
            l = [r.strip() for r in r1]
            l = [l[0],l[1],l[2],l[3]]

        locus += 1
        "exclude read if Illumina quality is low"
        try: Y = r1[0].split(" ")[1]
        except IndexError: Y = ""
        if "Y" in Y:
            Quality += 1

        else:
            "look for barcode preceding exact match of cutsite"
            barcode = 'N'*20
            if l[1][0:16].count(CUT) == 1:
                barcode = l[1].split(CUT)[0].strip()
            elif l[1][0:16].count(CUT) == 2:
                "in case cutsite is in barcode"
                barcode = CUT.join(l[1].split(CUT)[0:2]).strip()
                "unless falsely detected"
                if len(barcode) < 4:
                    barcode = l[1].split(CUT)[0].strip()
                if len(barcode) > 10:
                    barcode = l[1].split(CUT)[0].strip()
            #if len(barcode) != 6:
            #    print len(barcode), l[1]
            if len(barcode) < 13:
                "exclude the read if no cutsite/barcode found"
                if barcode in D:
                    D[barcode].append("\n".join(l).strip())
                    match += 1
                else:
                    D[barcode] = l
                    match += 1
        "write to file every 50Kth read" 
        if not locus % 50000:
            for bar in C:
                outF = open(WORK+"fastq/"+C[bar]+'.temp_'+str(num),'a')
                for barcode in D:
                    if matching(bar,barcode,maxmismatch):
                        if D[barcode]:
                            outF.write("\n".join(D[barcode])+'\n')
                        D[barcode] = []
                D[bar] = []
                outF.close()
                
    "write the remaining reads to file"
    for bar in C:
        outF = open(WORK+"fastq/"+C[bar]+'.temp_'+str(num),'a')
        for barcode in D:
            if matching(bar,barcode,maxmismatch):
                if D[barcode]:
                    outF.write("\n".join(D[barcode])+'\n')
        D[bar] = []
        outF.close()
                        
    print >>sys.stderr, "."
    fr1.close()
    if matchpairs: fr2.close()
                        
    with open(WORK+"stats/s1.sorting.txt",'a') as statout:
        "writes statistics out" 
        if matchpairs:
            statout.write("\t".join(map(str,[Raws[0].split("/")[-1], locus, locus-Quality, match]))+"\n")
        else:
            statout.write("\t".join(map(str,[Raws.split("/")[-1], locus, locus-Quality, match]))+"\n")


def writefunc(GLOB, Parallel,Bcode,CUT,matchpairs,maxmismatch,WORK):
    "create barcode dictionary"
    codetable = open(Bcode, 'r')
    if len(glob.glob(GLOB)) > 1:
        FS = [f for f in glob.glob(GLOB)]
    else:
        FS = glob.glob(GLOB)

    if matchpairs:
        Raws = combinefiles(GLOB)
    else:
        Raws = FS

    codes = [line.strip().split("\t") for line in codetable.readlines()]
    C = {}
    for line in codes:
        if line[0]:
            C[line[1].strip().upper()] = line[0]
    # print codes
    # if len(codes) == 1:
    #     C[codes[0][1]] = codes[0][0]
    # else:
    # print C

    num = 0
    "send jobs to multiprocess queue"
    work_queue = multiprocessing.Queue()
    submitted = 0
    for fs in Raws:
        if matchpairs:
            work_queue.put([C, [fs[0],fs[1]], CUT, matchpairs, num, maxmismatch, WORK])
            submitted += 1
        else:
            work_queue.put([C, fs, CUT, matchpairs, num, maxmismatch, WORK])
            submitted += 1
        num += 1

    result_queue = multiprocessing.Queue()

    "spawn workers, give function"
    jobs = []
    for i in range( min(Parallel,submitted) ):
        worker = Worker(work_queue, result_queue, barmatch)
        worker.start()
        jobs.append(worker)
    for job in jobs:
        job.join()



def matching(a,b, maxmismatch):
    "allows for one base difference between barcodes"
    if len(a) == len(b):
        t = [a[i]==b[i] for i in range(len(a))]
        if t.count(False) <= maxmismatch:
            #print a,b, t.count(False)
            return True


def main(Bcode, GLOB, CUT, matchpairs, Parallel, maxmismatch, WORK):
    "check for previous output"
    if not os.path.exists(WORK+'stats'):
        os.makedirs(WORK+'stats')
    if os.path.exists(WORK+'fastq'):
        if os.listdir(WORK+'fastq'):
            print ("\n\tfastq/ directory in working directory contains data, move/remove it before running step 1\n")
            sys.exit()
    else:
        os.makedirs(WORK+'fastq')

    sys.stderr.write("\n\tstep 1: sorting reads by barcode ")
    with open(WORK+"stats/s1.sorting.txt",'a') as statout:
        statout.write("\t".join(["file","locus","-lowqual","matched"])+"\n")

    writefunc(GLOB, Parallel, Bcode, CUT, matchpairs, maxmismatch, WORK)

    names = [line.split("\t")[0] for line in open(Bcode).readlines()]

    if len(glob.glob(GLOB)) > 1:
        for name in names:
            if len(glob.glob(WORK+"fastq/"+name+"*")) > 0:
                "remove very small files, probably errors"
                for ff in glob.glob(WORK+'fastq/'+name+"*"):
                    statinfo = os.stat(ff)
                    s = statinfo.st_size
                    if s < 10000:
                        os.system("rm "+ff)

    for name in names:
        if len(glob.glob(WORK+"fastq/"+name+"*")) > 0:
            os.system("cat "+WORK+"fastq/"+name+".temp_* > "+WORK+"fastq/"+name+".fq")

    if len(glob.glob(WORK+"fastq/*")) > 0:
        os.system(" ls "+WORK+"fastq/*temp_* | xargs rm" )

    # else:
    #     for name in names:
    #         os.system("mv "+WORK+"fastq/"+name+"*temp* "+WORK+"fastq/"+name+".fq")
