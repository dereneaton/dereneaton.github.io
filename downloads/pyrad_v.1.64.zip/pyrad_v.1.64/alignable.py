import numpy
import os,sys
import glob
import subprocess
import multiprocessing
from itertools import izip
from copy import copy
from potpour import *
from consensdp import unhetero, uplow, breakalleles

def stack(D):
    """
    from list of bases at a site D,
    returns an ordered list of counts of bases
    """
    L = len(D)
    counts = []
    for i in range(len(D[0])):
        R=Y=S=W=K=M=0
        for nseq in range(L):
            R += D[nseq][i].count("R")
            Y += D[nseq][i].count("Y")
            S += D[nseq][i].count("S")
            W += D[nseq][i].count("W")
            K += D[nseq][i].count("K")
            M += D[nseq][i].count("M")
        counts.append( [R,Y,S,W,K,M] )
    return counts


def countpolys(seqs):
    t = [tuple(seq) for seq in seqs]
    return max([sum(i) for i in stack(t)])


def alignfast(names,seqs,muscle):
    ST = "\n".join('>'+i+'\n'+j[0] for i,j in zip(names,seqs))
    cmd = "echo '"+ST+"' | "+muscle+" -quiet -in -"
    fout = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    return fout.stdout.read()


def polyaccept(maxpoly, MAXpoly, ln):
    passed = 1
    if 'p' in str(MAXpoly):
        if maxpoly > ln*float(MAXpoly.replace('p','')):
            passed = 0
    else:
        MAXpoly = int(MAXpoly)
        if maxpoly > MAXpoly:
            passed = 0
    if passed:
        return 1


def sortalign(stringnames):
    G = stringnames.split("\n>")
    GG = [i.split("\n")[0].replace(">","")+"\n"+"".join(i.split('\n')[1:]) for i in G]
    aligned = [i.split("\n") for i in GG]
    nn = [">"+i[0] for i in aligned]
    seqs = [i[1] for i in aligned]
    return nn,seqs



def alignFUNC(infile, minspecies, ingroup,
              MAXpoly, outname, maxSNP,
              muscle, minlen, exclude,
              overhang, WORK):
    f = open(infile)
    aout = open(WORK+".align_"+str("".join(infile.split("_")[-1])),'w')
    nout = open(WORK+".not_"+str("".join(infile.split("_")[-1])),'w')
    locus = paralog = g4 = dups = 0
    k = izip(*[iter(f)]*2)
    while 1:
        D = P = S = notes = ""
        try: d = k.next()
        except StopIteration : break
        locus += 1
        names = []
        seqs = []
        while d[0] != "//\n":
            "record names and seqs, remove # at end"
            "record the name into locus name. "
            nam = "_".join(d[0].split(">")[1].split("_")[:-2])
            if nam not in exclude:
                names.append("_".join(d[0].split(">")[1].split("_")[:-2]))
                seqs.append([d[1].strip()])
            d = k.next()
        if len(names) != len(set(names)):      ## no grouping un-clustered copies from same taxon
            dups += 1                          ## record duplicates in loci
            D = '%D'
        if len([i for i in names if i in ingroup])>(minspecies-1):  ## too few ingroup samples in locus
            g4 += 1
            stringnames = alignfast(names,seqs,muscle)
            nn, sss = sortalign(stringnames)
            maxpoly = countpolys(sss)                              ## count polys on aligned seqs
            if not D:
                if not polyaccept(maxpoly, MAXpoly, len(nn)):
                    P = '%P'
            bases = []
            for i in range(len(sss[0])):      ## create list of bases at each site
                site = [s[i] for s in sss]
                bases.append(site)
            basenumber = 0
            snpsite = [" " for i in range(len(sss[0]))]
            for site in bases:
                reals = [i for i in site if i not in list("N-")]
                if len(set(reals)) > 1:                                ## if site is variable
                    if sorted([reals.count(i) for i in set(reals)],reverse=True)[1] > 1: # not autapomorphy
                        snpsite[basenumber] = "*"                      ## mark PIS for outfile .align
                    else:                                              ## if autapormorphy
                        snpsite[basenumber] = '-'
                basenumber += 1
            zz = zip(nn,sss)
            pp = map(ffmin,sss)
            if overhang[0]:
                FM = min([i for i in pp if [j<=i for j in pp].count(True) > 3]) #minspecies-1])
            else:
                FM = max(pp)
            pp = map(ffmax,sss)
            if overhang[1]:
                SM = max([i for i in pp if [j>=i for j in pp].count(True) > 3]) #minspecies-1])
            else:
                SM = min(pp)
            zz.sort()
            if not (D or P):
                if (snpsite[FM:SM+1].count('*') > maxSNP):
                    S = "%S"
                #if (snpsite[FM:SM+1].count('-') > ((SM+1)-FM)/3.3):
                #    S = "%S"
                if ((SM+1)-FM) < minlen:
                    S = "%S"
            longname = max(map(len,[x for x,y in zz]))
            if len(D+P+S) == 0:
                for x,y in zz:                               ## write to stats file
                    space = ((longname+5)-len(x))
                    print >>aout, x+" "*space+y[FM:SM+1].upper()
                print >>aout, '//'+' '*(longname+3)+"".join(snpsite[FM:SM+1])+"|"+notes
            else:
                for x,y in zz:                               ## write to stats file
                    space = ((longname+5)-len(x))
                    print >>nout, x+" "*space+y.upper()
                print >>nout, '//'+D+P+S+' '*(longname+3-len(D+P+S))+"".join(snpsite)+"|"
    nout.close()
    aout.close()
    print '.',
    return locus #,aout,nout


def ffmin(x):
    d = []
    for i,j in enumerate(x):
        if j not in "-":
            d.append(i)
    return min(d)

def ffmax(x):
    d = []
    for i,j in enumerate(x):
        if j not in "-":
            d.append(i)
    return max(d)


def makealign(ingroup, minspecies, outname, infile,
              MAXpoly, parallel, maxSNP, muscle,
              minlen, exclude, overhang, WORK):

    ### break input file into chunks for n threads
    if glob.glob(WORK+".align") or glob.glob(WORK+".chunk"):
        os.system("rm "+WORK+".align* "+WORK+".chunk*")
    f = open(infile,'r').read().strip().split("//\n")
    pp = max(3,parallel)
    chunks = [0+(len(f)/pp)*i for i in range(pp)]
    for i in range(len(chunks)-1):
        ff = open(WORK+".chunk_"+str(i), 'w')
        ff.write( "//\n\n".join(f[chunks[i]:chunks[i+1]])+"//\n\n")
        ff.close()
    ff = open(WORK+".chunk_"+str(i+1), 'w')
    ff.write( "//\n\n".join(f[chunks[i+1]:])+"\n\n")
    ff.close()

    ### set up parallel
    work_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()
    for handle in glob.glob(WORK+".chunk*"):
        work_queue.put([handle, minspecies, ingroup, MAXpoly,
                        outname, maxSNP, muscle, minlen,
                        exclude,overhang, WORK])

    ## spawn workers
    jobs = []
    for i in range(pp):
        worker = Worker(work_queue, result_queue, alignFUNC)
        jobs.append(worker)
        worker.start()
    for j in jobs:
        j.join()

    locus = 0
    for handle in glob.glob(WORK+".chunk*"):
        locus += int(result_queue.get())

    ## output stats and delete temp files...
    cmd = "cat "+WORK+".align* > "+WORK+"outfiles/"+outname+".loci"
    os.system(cmd)                      ## outname add
    os.system("rm "+WORK+".align* "+WORK+".chunk*")
    cmd = "cat "+WORK+".not* > "+WORK+"outfiles/"+outname+".excluded_loci"
    os.system(cmd)                      ## outname add
    os.system("rm "+WORK+".not*")
    return locus


def makephy(ingroup, outgroups, outname, locus, WORK, singletons, minspecies, snp, usnp, longname):
    print "\n\tfinal stats written to:\n\t "+WORK+"stats/"+outname+".stats"
    print "\toutput files written to:\n\t "+WORK+"outfiles/ directory\n"
    statsout = open(WORK+"stats/"+outname+".stats",'w')   
    finalfile = open(WORK+"outfiles/"+outname+".loci").read() 
    notkept = open(WORK+"outfiles/"+outname+".excluded_loci").read()
    nloci = finalfile.count("|")
    npara = notkept.count("%P")
    ndups = notkept.count("%D")
    nMSNP = notkept.count("%S")

    print >>statsout, "\n"
    print >>statsout, str(locus+singletons)+" "*(12-len(str(locus)))+"## total loci across all samples"
    print >>statsout, str(nloci+npara+nMSNP)+" "*(12-len(str(nloci+npara+nMSNP)))+"## loci with > minsp containing data"
    print >>statsout, str(nloci+nMSNP)+" "*(12-len(str(nloci+nMSNP)))+"## loci with > minsp containing data & paralogs removed"
    print >>statsout, str(nloci)+" "*(12-len(str(nloci)))+"## loci with > minsp containing data & paralogs removed & final filtering\n"

    print >>statsout, "## number of loci recovered in final data set for each taxon."
    names = list(ingroup)+outgroups
    names.sort()
    print >>statsout, '\t'.join(['taxon','nloci'])
    ml = max(map(len,names))
    for name in names:
        print >>statsout, name+" "*(ml-len(name))+"\t"+str(finalfile.count(">"+name+" "))
    print >>statsout, '\n'

    print >>statsout, "## nloci = number of loci with data for exactly ntaxa"
    print >>statsout, "## ntotal = number of loci for which at least ntaxa have data"
    print >>statsout, '\t'.join(['ntaxa','nloci','saved','ntotal'])
    coverage = [i.count(">") for i in finalfile.split("|")[:-1]]
    if not coverage:
        print "\twarning: no loci meet 'min_sample' setting (line 11)\n\tno results written"
        sys.exit()
    coverage.sort()
    print >>statsout, str(1)+"\t"+str(singletons)
    tot = nloci
    for i in range(2,max(set(coverage))+1):
        if i>=minspecies:
            tot -= coverage.count(i-1)
            print >>statsout, str(i)+"\t"+str(coverage.count(i))+"\t*\t"+str(tot)
        else:
            print >>statsout, str(i)+"\t"+str(coverage.count(i))+'\t\t-'
    print >>statsout, "\n"

    print >>statsout, "## var = number of loci containing n variable sites."
    print >>statsout, "## pis = number of loci containing n parsimony informative sites."
    print >>statsout, '\t'.join(['n','var','PIS'])
    pis = [i.count("*") for i in finalfile.split("|")[:-1]]
    snps = [line.count("-") for line in finalfile.split("\n")[:-1] if "//" in line]
    print >>statsout, str(0)+"\t"+str(snps.count(0))+"\t"+str(pis.count(0))
    for i in range(1,max(max(set(snps))+1,max(set(pis))+1)):
        print >>statsout, str(i)+"\t"+str(snps.count(i)+pis.count(i))+"\t"+str(pis.count(i))
    print >>statsout, "total var=",sum(snps+pis)
    print >>statsout, "total pis=",sum(pis)

    ## output .snps .snp and .phy files
    F = {}
    S = {}
    Si = {}
    for name in list(names):
        F[name] = []
        S[name] = []
        Si[name] = []
    loci = [i for i in finalfile.split("|")[:-1]]
    for loc in loci:
        ns = []
        ss = []
        for line in loc.split("\n"):
            if ">" in line:
                ns.append(line.split(" ")[0].replace(">",""))
                ss.append(line.split(" ")[-1])
            if "//" in line:
                pis = [i[0] for i in enumerate(line) if i[1] in list('*-')]
                cov = {}
        longname = max(map(len,ns))
        for tax in F:
            if tax in ns:
                F[tax].append(ss[ns.index(tax)])
                if pis:
                    for base in pis:
                        base -= (longname+6)
                        S[tax].append(ss[ns.index(tax)][base])
                        if base not in cov:
                            cov[base] = 1
                        else:
                            cov[base] += 1
                        if ss[ns.index(tax)][base] != '-':
                            cov[base] += 1
            else:
                F[tax].append("N"*len(ss[0]))
                if pis:
                    for base in pis:
                        S[tax].append("N")
                    Si[tax].append("N")
        maxlist = []
        for j,k in cov.items():
            if k == max(cov.values()):
                maxlist.append(j)
        if maxlist:
            rando = pis[numpy.random.randint(len(pis))]
            rando -= (longname+6)
        for tax in F:
            if tax in ns:
                if pis:
                    Si[tax].append(ss[ns.index(tax)][rando])
            if pis:
                S[tax].append(" ")
            else:
                S[tax].append("_ ")
                    
    superout = open(WORK+"outfiles/"+outname+".phy",'w')
    print >>superout, len(F),len("".join(F.values()[0]))
    SF = list(F.keys())
    SF.sort()
    for i in SF:
        print >>superout, i, "".join(F[i])
    superout.close()

    if snp:
        snpsout = open(WORK+'outfiles/'+outname+".snps",'w')
        print >>snpsout, "## %s taxa, %s loci, %s snps" % (len(S), len("".join(S.values()[0]).split(" "))-1, len("".join(S.values()[0])))
        for i in SF:
            print >>snpsout, i+(" "*(longname-len(i)+3))+"".join(S[i])
        snpsout.close()

    if usnp:
        snpout = open(WORK+'outfiles/'+outname+".unlinked_snps",'w')
        print >>snpout, len(Si),len("".join(Si.values()[0]))
        for i in SF:
            print >>snpout, i+(" "*(longname-len(i)+3))+"".join(Si[i])
        snpout.close()


def makehaplos(infile, longname):
    outfile = open(infile.replace(".loci",".alleles"),'w')
    lines = open(infile).readlines()
    writing = []
    for line in lines:
        if ">" in line:
            a,b = line.split(" ")[0],line.split(" ")[-1]
            a1,a2 = breakalleles(b.strip())
            writing.append(a+"_0"+" "*(longname-len(a)+4)+a1)
            writing.append(a+"_1"+" "*(longname-len(a)+4)+a2)
        else:
            writing.append(line.strip())
    outfile.write("\n".join(writing))
    outfile.close()


def makenex(infile, longname):
    data = open(infile).readlines()
    oo = open(infile.replace(".phy",".nex"),'w')

    ntax,nchar = data[0].strip().split(" ")

    print >>oo, "#NEXUS"
    print >>oo, "BEGIN DATA;"
    print >>oo, "  DIMENSIONS NTAX=%s NCHAR=%s;" % (ntax,nchar)
    print >>oo, "  FORMAT DATATYPE=DNA MISSING=N GAP=- INTERLEAVE=YES;"
    print >>oo, "  MATRIX"

    L = {}
    for line in data[1:]:
        a = line.lstrip().rstrip().split(" ")
        L[a[0]] = a[-1]

    n=0
    sz = 100
    while n<len(a[-1]):
        for tax in L:
            print >>oo, "  "+tax+" "*((longname-len(tax))+3)+L[tax][n:n+sz]
        n += sz
        print >>oo, ""
    print >>oo, ';'
    print >>oo, 'END;'
    oo.close()
    

def cmd_exists(cmd):
    return subprocess.call("type " + cmd, shell=True, 
        stdout=subprocess.PIPE, stderr=subprocess.PIPE) == 0


def main(outgroup, minspecies, outname,
         infile, MAXpoly, parallel,
         maxSNP, muscle, minlen,
         exclude,overhang,outform,WORK,clustprefix):

    if glob.glob(WORK+".chunk_*"):
        os.system("rm "+WORK+".chunk_*")
    if glob.glob(WORK+".align_*"):
        os.system("rm "+WORK+".align_*")
    if glob.glob(WORK+".not_*"):
        os.system("rm "+WORK+".not_*")

    ## output directory
    if not os.path.exists(WORK+'outfiles'):
        os.makedirs(WORK+'outfiles')

    " find muscle"
    if not cmd_exists(muscle):
        print "cannot find muscle, edit path in input file"
        sys.exit()

    ## read names from file
    f = open(infile,'r').readlines()
    names = set(["_".join(i.split(">")[1].split("_")[:-2]) for i in f if ">" in i])
    if '.clustR_' in infile:
        shuf = open(infile.replace(".clustR",".shuf"),'r').read()
    else:
        shuf = open(infile.replace(".clust",".shuf"),'r').read()
    if clustprefix:
        sing1 = open(WORK+"prefix/cat.u").readlines()
        nseedshit = len(set([i.split("\t")[1] for i in sing1]))
        nseeds = open(WORK+"prefix/cat._tempU").read().count(">")
        singletons = nseeds-nseedshit
    else:
        singletons = shuf.count(">")-"".join(f).count(">")

    if exclude:
        exclude = exclude.strip().split(",")
    else:
        exclude = []
    if outgroup:
        outgroup = outgroup.strip().split(",")
    else:
        outgroup = []
    for i in exclude:
        names.discard(i)
    ingroup = copy(names)
    for i in outgroup:
        if i in ingroup:
            ingroup.remove(i)

    toprint = [i for i in list(ingroup) if i not in exclude]
    toprint.sort()
    print '\tingroup', toprint
    toprint = [i for i in outgroup if i not in exclude]
    toprint.sort()
    print '\taddon', toprint
    print '\texclude', exclude
    print "\t",

    locus = makealign(ingroup, minspecies, outname, infile,
                      MAXpoly, parallel, maxSNP, muscle,
                      minlen, exclude, overhang, WORK)

    longname = max(map(len, list(ingroup)+list(outgroup)))
    formats = outform.split(",")
    usnp = snp = 0
    if 'u' in formats:
        usnp = 1
    if 's' in formats:
        snp = 1
    makephy(ingroup, outgroup, outname, locus, WORK, singletons, minspecies, snp, usnp, longname)
    if 'a' in formats:
        makehaplos(WORK+"outfiles/"+outname+".loci", longname)
    if "n" in formats:
        makenex(WORK+"outfiles/"+outname+".phy", longname)


