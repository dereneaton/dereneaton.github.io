import multiprocessing
import glob
import itertools
import sys
import scipy.stats
import scipy.misc
import numpy
import os
import operator
from potpour import Worker


def binomprobr(n1,n2,e,r):
    """
    given two bases are observed at a site
    n1 and n2, and the error rate e, the
    probability the site is truly aa,bb,ab
    is calculated using binomial distribution
    as in Li_et al 2009, 2011, and if
    coverage > 500, 500 reads were randomly
    sampled.
    """
    prior_homo = ((1.-r)/2.)
    prior_het = r
    ab = scipy.misc.comb(n1+n2,n1)/(2.**(n1+n2))
    aa= scipy.stats.binom.pmf(n1,n1+n2,e)
    bb= scipy.stats.binom.pmf(n2,n1+n2,e)
    aa = aa*prior_homo
    bb = bb*prior_homo
    ab = ab*prior_het
    Q = [aa,bb,ab]
    Qn = ['aa','bb','ab']
    P = max(Q)/float(aa+bb+ab)
    return [P,Qn[Q.index(max(Q))]]


def simpleconsens(n1,n2):
    """
    consensus calling for sites
    with too low of coverage for
    statistical calling. Only used
    with 'lowcounts' option.
    """
    Qn = ['aa','bb','ab']
    if not n2:
        P = 0.99
        aa = 1.0
        ab = bb = 0.0
    else:
        P = 0.99
        aa = bb = 0.0
        ab = 1.0
    Q = [aa,bb,ab]
    return [P,Qn[Q.index(max(Q))]]


def hetero(n1,n2):
    """
    returns IUPAC symbol for ambiguity bases,
    used for polymorphic sites.
    """
    D = {('G','A'):"R",
         ('G','T'):"K",
         ('G','C'):"S",
         ('T','C'):"Y",
         ('T','A'):"W",
         ('C','A'):"M"}
    a = D.get((n1,n2))
    b = D.get((n2,n1))
    if a:
        return a
    else:
        return b


def unhetero(amb):
    amb = amb.upper()
    " returns bases from ambiguity code"
    D = {"R":("G","A"),
         "K":("G","T"),
         "S":("G","C"),
         "Y":("T","C"),
         "W":("T","A"),
         "M":("C","A")}
    return D.get(amb)


def uplow(b1):
    " allele precedence "
    " G > T > C > A "
    D = {('G','A'):"G",
         ('A','G'):"G",
         ('G','T'):"G",
         ('T','G'):"G",
         ('G','C'):"G",
         ('C','G'):"G",
         ('T','C'):"T",
         ('C','T'):"T",
         ('T','A'):"T",
         ('A','T'):"T",
         ('C','A'):"C",
         ('A','C'):"C"}
    r = D.get(b1)
    if not r:
        r = b1[0]
    return r
    

def findalleles(consensus,sss,bbb):
    cons = list(consensus)
    " relative to first base "
    bigbase = uplow(tuple([i.split("_")[0] for i in bbb]))
    bigallele = bbb.index([i for i in bbb if i.split("_")[0] == bigbase][0])
    for k in range(1,len(sss)):
        c = uplow(tuple([i.split("_")[k] for i in bbb]))
        which = bbb.index([i for i in bbb if i.split("_")[k] == c][0])
        if bbb[bigallele] != bbb[which]:
            cons[sss[k]] = cons[sss[k]].lower()
    return "".join(cons)


def breakalleles(consensus):
    """ break ambiguity code consensus seqs
    into two alleles """
    a1 = ""
    a2 = ""
    bigbase = ""
    for base in consensus:
        if base in tuple("RKSYWM"):
            a,b = unhetero(base)
            d = set([a,b])
            a1 += uplow((a,b))
            a2 += d.difference(uplow((a,b))).pop()
            if not bigbase:
                bigbase = uplow((a,b))
        elif base in tuple("rksywm"):
            a,b = unhetero(base)
            d = set([a,b])
            a2 += uplow((a,b))
            a1 += d.difference(uplow((a,b))).pop()
        else:
            a1 += base
            a2 += base
    return a1,a2



def stack(D):
    """
    from list of bases at a site D,
    returns an ordered list of counts of bases
    """
    L = len(D)
    counts = []
    for i in range(len(D[0])):
        A=C=T=G=N=M=0
        for nseq in range(L):
            A += D[nseq][i].count("A")
            C += D[nseq][i].count("C")
            T += D[nseq][i].count("T")
            G += D[nseq][i].count("G")
            N += D[nseq][i].count("N")
            M += D[nseq][i].count("-")
        counts.append( [[A,C,T,G],N,M] )
    return counts


def ffmin(x):
    d = []
    for i,j in enumerate(x):
        if j not in ["-","N"]:
            d.append(i)
    return min(d)

def ffmax(x):
    d = []
    for i,j in enumerate(x):
        if j not in ["-","N"]:
            d.append(i)
    return max(d)


def removerepeat_Ns(shortcon):
    """
    checks for interior Ns in consensus seqs
    remove those that arise next to repeats of
    3 bases, which may be sequencing errors on
    deep coverage repeats """
    Nlocs = [i for i,j in enumerate(shortcon) if j=="N"]
    repeats = set()
    for n in Nlocs:
        r1 = len(set(list(shortcon)[n-3:n]))
        if r1 < 2:
            repeats.add(n)
        r2  = len(set(list(shortcon)[n+1:n+4]))
        if r2 < 2:
            repeats.add(n)
    return "".join([j for (i,j) in enumerate(shortcon) if i not in repeats])


def consensus(infile,E,H,mindepth,endcut,maxN,maxH,
              output_errs,haplos,CUT,
              upperSD,matchpairs,strict,
              lowcounts,minlen):
    """
    from a clust file f,
    reads in all copies at a locus and sorts
    bases at each site, tests for errors at the
    site according to error rate, calls consensus
    """
    f = open(infile)
    k = itertools.izip(*[iter(f)]*2)
    bases = ['A','C','T','G']
    Dic = {}
    Errors = []
    haplo = []
    locus = minsamplocus = npoly = P = 0
    while 1:
        try :
            first = k.next()
        except StopIteration: break
        itera = [first[0],first[1]]
        fname = itera[0].strip().split(";")[0]
        leftjust = rightjust = None
        # if "_r1;" in first[1]:
        #     leftjust = first[1].index([i for i in itera[1] if i not in list("-N")][0])
        # elif "_r2;" in first[1]:
        #     rightjust = first[1].rindex([i for i in itera[1] if i not in list("-N")][0])
        " lists and variables for this locus"
        S       = []         ## list for sequence data
        alleles = []         ## for measuring # alleles, detect paralogs
        errors  = []         ## recording error locations
        locus += 1           ## recording n loci
        diploid = 0          ## for measuring # alleles, detect paralogs
        nHs = 0              ## will record heterozygous sites in this locus
        consensus = ""       ## empty vector for consensus sequence
        basenumber = 1       ## for recording error locations
        lefts = []
        rights = []
        while itera[0] != "//\n":
            nreps = int(itera[0].strip().split(";")[1].replace("size=",""))
            if itera[0].strip().split(";")[2] == "":
                if "_r1;" in itera[0]:
                    leftjust = itera[1].index([i for i in itera[1] if i not in list("-N")][0])
                elif "_r2;" in itera[0]:
                    rightjust = itera[1].rindex([i for i in itera[1] if i not in list("-N")][0])
            lefts.append(itera[1].index([i for i in itera[1] if i not in list("-N")][0]))
            rights.append(itera[1].rindex([i for i in itera[1] if i not in list("-N")][0]))
            for i in range(nreps):
                S.append(tuple(itera[1].strip())) #.replace("-","N")))       ## replace '-' with N
            itera = k.next()
        if any([i < leftjust for i in lefts]):
            rightjust = min(rights)
        if any([i < rightjust for i in rights]):
            leftjust = max(lefts)
        " record overlap of paired reads"
        if matchpairs:
            if 'clustSC' in infile:
                fname += "<"
            elif 'clustSR' in infile:
                L1 = len("".join(S[0]).lstrip("N").strip('N'))
                L2 = len("".join(S[0]))
                if (L2 - L1) > 9:
                    fname += "<"
        if (len(S) > mindepth-1) and (len(S) < upperSD):  ## upper limit is meandepth + 2 SD
            minsamplocus += 1
            if ".clustSC" in infile:
                """ cuts off overhanging ends of trimmed seqs
                (the missed trims due to errors)"""
                pp = map(ffmin,S)
                FM = max(pp)
                pp = map(ffmax,S)
                SM = min(pp)
                for s in range(len(S)):
                    S[s] = S[s][FM:SM+1]
            #if ".clustSR" in infile:
            if "<" in fname:
                for s in range(len(S)):
                    if rightjust:
                        S[s] = S[s][leftjust:rightjust+1]
                    else:
                        S[s] = S[s][leftjust:rightjust]
            #print rightjust,leftjust, '$'
            RAD = stack(S)
            if endcut:
                RAD = RAD[:-endcut]
            for site in RAD:
                nchanged = 0                      ## for >500 depth sites
                if sum(site[0]) < mindepth:
                    cons = "N"; n1 = mindepth-1; n2=0   ## prevents zero division error.
                else:
                    n1,n2,n3,n4 = sorted(site[0],reverse=True)
                    #" third base cannot be more than .20 presence in diploids
                    quickthirdbasetest = 0
                    if haplos == 2:
                        if float(n3)/(n1+n2+n3+n4) > 0.20:
                            quickthirdbasetest = 1
                    if not quickthirdbasetest:
                        if n1+n2 >= 500:   ## if > 500, random sample 500 
                            firstfivehundred = numpy.array(tuple("A"*n1+"B"*n2))
                            numpy.random.shuffle(firstfivehundred)
                            nchanged = 1
                            oldn1 = n1
                            oldn2 = n2
                            n1 = list(firstfivehundred[:500]).count("A")
                            n2 = list(firstfivehundred[:500]).count("B")
                        if lowcounts:       ## include low count sites or no
                            if n1+n2 > (mindepth-1):
                                P,who = binomprobr(n1,n2,float(E),H)
                            else:
                                P,who = simpleconsens(n1,n2)
                        else:
                            P,who = binomprobr(n1,n2,float(E),H)
                        if float(P) >= 0.95:
                            if who in 'ab':
                                if nchanged:
                                    a = [i for i,l in enumerate(site[0]) if l == oldn1]
                                else:
                                    a = [i for i,l in enumerate(site[0]) if l == n1]
                                if len(a)==2:       ## alleles came up equal freq.
                                    cons = hetero(bases[a[0]],bases[a[1]])
                                    alleles.append(basenumber)
                                else:               ## alleles came up diff freq.
                                    if nchanged:
                                        b= [i for i,l in enumerate(site[0]) if l == oldn2]
                                    else:
                                        b= [i for i,l in enumerate(site[0]) if l == n2]
                                    "three alleles came up equal, only need if diploid paralog filter off"
                                    if a == b:
                                        cons = hetero(bases[a[0]],bases[a[1]])
                                    else:
                                        cons = hetero(bases[a[0]],bases[b[0]])
                                    alleles.append(basenumber)
                                nHs += 1
                            else:
                                if nchanged:
                                    cons = bases[site[0].index(oldn1)]
                                else:
                                    cons = bases[site[0].index(n1)]
                        else:
                            cons = "N"
                    else:
                        "paralog flag"
                        cons = "@"
                consensus += cons

                if output_errs:
                    if n1:
                        errors.append( [locus, basenumber, n1+n2, float(n1)/(n1+n2), P, cons])
                basenumber += 1

            " only allow maxH polymorphic sites in a locus "
            if "@" not in consensus:
                if nHs <= maxH:
                    " counts number of alleles currently only for diploids "
                    if haplos == 2:
                        al = []
                        if len(alleles) > 1:
                            for i in S:
                                d = ""
                                for z in alleles:
                                    if i[z-1] in unhetero(consensus[z-1]):
                                        d += i[z-1]+"_"
                                if "N" not in d:
                                    if d.count("_") == len(alleles):
                                        al.append(d.rstrip("_"))
                            " remove singletons representing an error at a heterozygous site \
                            that changed the base to the alternate allele at that site "
                            if len(al) >= 5:
                                al = [i for i in al if al.count(i) > len(al)/20.]
                            AL = sorted(set(al), key=al.count)
                            diploid = len(AL)

                            " set correct alleles relative to first polymorphic base"
                            if AL:
                                if diploid <= haplos:
                                    sss = [zz-1 for zz in alleles]
                                    consensus = findalleles(consensus,sss,AL)
                                else:
                                    consensus += "@E"
                            else:
                                consensus += "@A"

                    if "@" not in consensus:
                        " strip N's from either end "
                        shortcon = consensus.lstrip("N").rstrip("N").replace("-","N")
                        shortcon = removerepeat_Ns(shortcon)
                        if shortcon.count("N") <= maxN:     ## only allow maxN internal "N"s in a locus
                            if len(shortcon) >= minlen:      ## minimum length set to 36
                                npoly += nHs
                                Dic[fname] = shortcon
                                if output_errs:
                                    Errors += errors


    with open(infile.replace(".clustS",".consens"),'w+') as consens:
        for i in Dic.items():
            consens.write(str(i[0])+'\n'+str(i[1])+"\n")
    sys.stderr.write(".")

    if output_errs:
        errors = open(infile.replace(".clustS",".err"),'w+')  
        print >>errors, "loc\tpos\tncopy\tn1/ncopy\tP\tbase"
        for e in Errors:
            print >>errors, "\t".join([str(i) for i in e])
        errors.close()
    nsites = sum(map(len,Dic.values()))
    ldic = len(Dic)
    try: NP = npoly/float(nsites)
    except ZeroDivisionError: NP = 0
    return [infile.split('/')[-1], locus, minsamplocus, ldic, nsites, npoly, round(NP,7)]



def upSD(handle,mindepth):
    " function to calculate mean and SD of clustersize"
    infile = open(handle)
    L = itertools.izip(*[iter(infile)]*2)
    a = L.next()[0].strip()
    depth = []
    d = int(a.split(";")[1].replace("size=",""))
    while 1:
        try: a = L.next()[0].strip()
        except StopIteration: break
        if a != "//":
            d += int(a.split(";")[1].replace("size=",""))
        else:
            depth.append(d)
            d = 0
    infile.close()
    keep = [i for i in depth if i>=(mindepth)]
    if keep:
        me = numpy.mean(keep)
        std = numpy.std(keep)
    else:
        me = 0.0
        std = 0.0
    return me, std


def main(Parallel, E, H, ID, mindepth, match, endcut, maxN,
         maxH, output_error_locs, haplos, barcode, CUT,
         matchpairs, strict, lowcounts, minlen, WORK, maxstack):

    " find clust.xx directory "
    if not os.path.exists(WORK+'clust'+ID):
        print  "\terror: could not find "+WORK+"clust"+str(ID)+"/ directory,"+ \
                "\n\t\tif you changed the clustering threshold you must transfer *.clustS"+ \
                "\n\t\tfiles to a new directory named clust.xx with xx replaced by new clustering threshold"
        sys.exit()

    " load up work queue"
    work_queue = multiprocessing.Queue()

    " iterate over files"
    outfolder = WORK+'clust'+str(ID)
    HH = glob.glob(outfolder+"/"+match+".clustS*")
    stringout = "\n\tstep 5: created consensus seqs for %i samples, using E=%.5f H=%.5f\n\t" % (len(HH),E,H)
    sys.stderr.write(stringout)
    
    if len(HH) > 1:
        " sort files by size"
        for i in range(len(HH)):
            statinfo = os.stat(HH[i])
            HH[i] = HH[i],statinfo.st_size
        HH.sort(key=operator.itemgetter(1))
        FS = [f[0] for f in HH][::-1]
    else: FS = HH
    REMOVE = glob.glob('clust'+ID+"/cat.*")
    FS = [f for f in FS if f not in REMOVE]
    submitted = 0
    for handle in FS:
        if handle.replace('.clustS','.consens').replace('.clust','.consens') not in glob.glob(outfolder+"/*"):
            m,sd = upSD(handle,mindepth)
            if maxstack == "2SD":
                upperSD = max(500,m+(sd*2.5))
            else:
                upperSD = int(maxstack)
            work_queue.put([handle,E,H,mindepth,endcut,maxN,
                            maxH,output_error_locs,haplos,CUT,
                            upperSD,matchpairs,strict,lowcounts,
                            minlen])
            submitted += 1
        else:
            print "\tskipping "+handle.replace(".clustS",".consens")+\
                  ', it already exists in '+outfolder+"/"


    " create a queue to pass to workers to store the results"
    result_queue = multiprocessing.Queue()

    " spawn workers"
    jobs = []
    #for i in range(Parallel):
    for i in range( min(Parallel,submitted) ):
        worker = Worker(work_queue, result_queue, consensus)
        jobs.append(worker)
        worker.start()
    for j in jobs:
        j.join()

    " get results"
    stats = open(WORK+'stats/s5.consens.txt','a+')
    print >>stats,  "taxon"+" "*15+"\tnloci\tf1loci\tf2loci\tnsites\tnpoly\t%poly"
    for i in range(submitted):
        a,b,c,d,e,f,g = result_queue.get()
        print >> stats, "\t".join(map(str,[a+" "*(20-len(a)),b,c,d,e,f,g]))
    print >>stats, """
    ## nloci = number of loci
    ## f1loci = number of loci with >N depth coverage
    ## f2loci = number of loci with >N depth and passed paralog filter
    ## nsites = number of sites across f loci
    ## npoly = number of polymorphic sites in nsites
    ## %poly = percentage of sites that are polymorphic"""
    stats.close()




