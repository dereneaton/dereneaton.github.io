import os
import sys
import itertools
import numpy
import random
import glob
import subprocess
from consensdp import unhetero, uplow, breakalleles



def comp(seq):
    seq = seq.replace("A",'u')\
             .replace('T','v')\
             .replace('C','x')\
             .replace('G','z')\
             .replace('u','T')\
             .replace('v','A')\
             .replace('x','G')\
             .replace('z','C')
    seq = seq.replace('R','u')\
             .replace('Y','v')\
             .replace('K','x')\
             .replace('M','z')\
             .replace('u','Y')\
             .replace('v','R')\
             .replace('x','M')\
             .replace('z','K')
    seq = seq.replace('r','u')\
             .replace('y','v')\
             .replace('k','x')\
             .replace('m','z')\
             .replace('u','y')\
             .replace('v','r')\
             .replace('x','m')\
             .replace('z','k')
    return seq


def cmd_exists(cmd):
    return subprocess.call("type " + cmd, shell=True, 
        stdout=subprocess.PIPE, stderr=subprocess.PIPE) == 0



def cluster(UCLUST, handle, ID, radgbs, quiet, addon, clustprefix, complementmatch, WORK):
    C = " -cluster_smallmem "+handle
    if radgbs:
        P = " -strand both"
        if addon != "R":
            COV = " -query_cov "+str(complementmatch) #+" -target_cov "+str(complementmatch)
        else:
            COV = " -query_cov .90"
    else:
        #P = " -leftjust "
        P = ""
        COV = " -query_cov .90 " 
    if clustprefix:
        N = " -notmatched "+WORK+"prefix/"+handle.split("/")[-1].replace(".haplos","._temp")
        U = " -userout "+WORK+"prefix/"+handle.split("/")[-1].replace(".haplos",".u")
    else:
        N = ""
        U = " -userout "+handle.replace(".haplos",".u")
    if quiet:
        Q = " -quiet "
    else:
        Q = " "
    cmd = UCLUST+\
        C+\
        P+\
        " -id "+ID+\
        U+\
        " -userfields query+target+id+gaps+qstrand+qcov"+\
        " -maxaccepts 1"+\
        " -maxrejects 0"+\
        " -fulldp"+\
        " -usersort"+\
        COV+\
        N+\
        Q
        #" -hardmask"+\
    os.system(cmd)


def makeclust(handle,radgbs,addon,clustprefix,minmatch,WORK):
    if not clustprefix:
        Userout = open(handle.replace(".haplos",".u"))
        outfile = open(handle.replace(".haplos",".clust"+addon),'w')
    else:
        Userout = open(WORK+'prefix/'+handle.split("/")[-1].replace(".haplos",".u"))
        outfile = open(WORK+'prefix/'+handle.split("/")[-1].replace(".haplos",".seed"),'w')
        nomatch = open(WORK+'prefix/'+handle.split("/")[-1].replace(".haplos","._temp"))
    ## load full fasta file into a Dic
    D = {}
    f = open(handle.replace(".haplos",".consens"))
    L = itertools.izip(*[iter(f)]*2)
    while 1:
        try: a,b = L.next()
        except StopIteration: break
        D[a.strip()] = b.strip()
    f.close()
    ## load .u info into a Dic
    U = {}
    for line in [line.split("\t") for line in Userout.readlines()]:
        if ">"+line[1] in U:
            U[">"+line[1]].append([">"+line[0],line[4]])
        else:
            U[">"+line[1]] = [[">"+line[0],line[4]]]

    if clustprefix:
        if int(minmatch) == 1:
            NO = nomatch.read().strip().split(">")[1:]
            for no in NO:
                nn = no.split("\n")
                s1 = ">"+nn[0].strip()+"\n"
                s2 = "".join(nn[1:]).replace("\n","").upper()
                outfile.write(s1+s2+"\n//\n")
                
        for key,values in U.items():
            if (len(values)+1) >= int(minmatch):
                seq = key+"\n"+D[key]+"\n"
                seq += "//\n"
                outfile.write(seq)
    else:
        # map sequences to clust file in order
        seq = ""
        for key,values in U.items():
            seq = key+"\n"+D[key]+'\n'
            S = [i[0] for i in values]
            R = [i[1] for i in values]
            for i in range(len(S)):
                if R[i] == "+":
                    seq += S[i] + '\n' + D[S[i]] + "\n"
                else:
                    seq += S[i] + '\n' + comp(D[S[i]][::-1]) + "\n"
            seq += "//\n"
            outfile.write(seq)
    outfile.close()
    Userout.close()
    if clustprefix: nomatch.close()


def main(UCLUST, ID, radgbs, clustprefix, outg, seed, subset,
         addon, quiet, minmatch, complementmatch, WORK):


    " find usearch"
    if not cmd_exists(UCLUST):
        print "\tcannot find usearch, edit path in input file"
        sys.exit()

    out = open(WORK+'clust'+ID+'/cat.shuf_'+addon,'w')
    if not clustprefix:
        FS = glob.glob(WORK+"clust"+ID+"/"+subset+"*.consens"+addon)
    else:
        FS = glob.glob(WORK+"clust"+ID+"/"+addon+"*.consens")

    if not clustprefix:
        if outg:
            outgroup = outg.strip().split(",")
            if len(outgroup) > 1:
                for s in outgroup:
                    FS.remove(WORK+"clust"+ID+"/"+s+".consens"+addon)
            else:
                FS.remove(WORK+"clust"+ID+"/"+outgroup[0]+".consens"+addon)

    try: FS.remove(WORK+"clust"+ID+"/cat.consens_"+addon)
    except ValueError: pass
    try: FS.remove(WORK+"clust"+ID+"/cat.consens_"+addon)
    except ValueError: pass

    for handle in FS:
        f = open(handle)
        k = itertools.izip(*[iter(f)]*2)
        while 1:
            try: a = k.next()
            except StopIteration: break
            print >>out, a[0].strip()+"    "+a[1].strip()
        f.close()
    out.close()

    if addon:
        sys.stderr.write('\n\tstep 6: clustering across '+str(len(FS))+' samples at '+`ID`+' similarity for group ('+str(addon)+')\n\n')
    else:
        sys.stderr.write('\n\tstep 6: clustering across '+str(len(FS))+' samples at '+`ID`+' similarity \n\n')

    #print ",".join([i.split("/")[-1] for i in FS])

    """ randomize input order  """
    if seed:
        random.seed(seed)
    ff = open(WORK+'clust'+ID+'/cat.shuf_'+addon,'r')
    D = [i.strip().split("    ") for i in ff]
    DD = ["".join([i[0]+" "*(20-len(i[0])),i[1]]) for i in D][::-1]
    with open(WORK+'clust'+ID+'/cat.shuf_'+addon,'r') as source:
        data = [ (random.random(), line) for line in source ]
    data.sort()
    with open(WORK+'clust'+ID+'/cat.consens_1'+addon,'w+') as target:
        for _, line in data:
            target.write( line )
    source.close()
    target.close()

    """ sort list by length, still randomized within size class """
    D = [i.split('    ') for i in open(WORK+"clust"+ID+"/cat.consens_1"+addon).readlines()]
    DD = ["".join([i[0]+" "*(50-len(i[0])),i[1]]) for i in D]
    DD.sort(key=len)
    del D
    D = ["**".join([i.split(" ")[0],i.split(" ")[-1]]) for i in DD]
    k = iter(D[::-1])
    out = open(WORK+'clust'+ID+'/cat.consens_'+addon,'w+')
    while 1:
        try: a,b = k.next().split("**")
        except StopIteration: break
        print >>out, a+'\n'+b.strip()
    out.close()
    os.remove(WORK+'clust'+ID+'/cat.consens_1'+addon)

    """ add outgroup taxa back onto end of file."""
    if not clustprefix:
        if outg:
            fout = open(WORK+"clust"+ID+"/cat.consens_"+addon, 'a')
            outgroup = outg.strip().split(',')
            for s in outgroup:
                f = open(WORK+"clust"+ID+"/"+s+".consens"+addon)
                k = itertools.izip(*[iter(f)]*2)
                while 1:
                    try: a = k.next()
                    except StopIteration: break
                    print >>fout, a[0].strip()+"\n"+a[1].strip()
                f.close()
            fout.close()

    """ convert ambiguity codes into a sampled haplotype for any sample
    but save ambiguities for later """
    outhandle = WORK+"clust"+ID+"/cat.haplos_"+addon
    outhaplos = open(outhandle,'w')
    infile = open(WORK+"clust"+ID+"/cat.consens_"+addon)
    lines = infile.readlines()
    writinghaplos = []
    for line in lines:
        if ">" in line:
            writinghaplos.append(line.strip())
        else:
            allele = breakalleles(line)[0]
            writinghaplos.append(allele.strip())
    outhaplos.write("\n".join(writinghaplos))
    outhaplos.close()
    infile.close()

    cluster(UCLUST,outhandle,ID,radgbs,quiet,addon,clustprefix,complementmatch,WORK)
    makeclust(outhandle,radgbs,addon,clustprefix,minmatch,WORK)





