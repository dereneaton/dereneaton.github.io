import scipy.stats
import scipy.optimize
import numpy
import itertools
import sys
import glob
import multiprocessing
import os
import operator
from potpour import Worker



def makeP(N):
    """ returns a list of freq. for ATGC"""
    sump = sum([sum(i) for i in N])
    try: p1 = sum([float(i[0]) for i in N])/sump
    except ZeroDivisionError: p1 = 0.0
    try: p2 = sum([float(i[1]) for i in N])/sump
    except ZeroDivisionError: p2 = 0.0
    try: p3 = sum([float(i[2]) for i in N])/sump
    except ZeroDivisionError: p3 = 0.0
    try: p4 = sum([float(i[3]) for i in N])/sump
    except ZeroDivisionError: p4 = 0.0
    return [p1,p2,p3,p4]


def L1(E,P,N):
    """probability homozygous"""
    h = []
    s = sum(N)
    for i,l in enumerate(N):
        p = P[i]
        b = scipy.stats.binom.pmf(s-l,s,E)
        h.append(p*b)
    return sum(h)


def L2(E,P,N):
    """probability of heterozygous"""
    h = []
    s = sum(N)
    for l,i in enumerate(N):
        for j,k in enumerate(N):
            if j>l:
                one = 2.*P[l]*P[j]
                two = scipy.stats.binom.pmf(s-i-k,s,(2.*E)/3.)
                three = scipy.stats.binom.pmf(i,k+i,0.5)
                four = 1.-(sum([q**2. for q in P]))
                h.append(one*two*(three/four))
    return sum(h)


def totlik(E,P,H,N):
    """ total probability """
    lik = ((1-H)*L1(E,P,N)) + (H*L2(E,P,N))
    return lik


def LL(x0,P,Tab):
    """ Log likelihood score given values [H,E] """
    H = x0[0]
    E = x0[1]
    L = []
    if (H <= 0.) or (E <= 0.):
        r = numpy.exp(100)
    else:
        for i in Tab:
            ll = totlik(E,P,H,i[0])
            if ll > 0:
                L.append(i[1] * numpy.log(ll))
        r = -sum(L)
        #print "\t".join(map(str,[r, H, E]))
    return r


def table_c(N):
    """ makes a dictionary with counts of base counts [x,x,x,x]:x,
    speeds up Likelihood calculation"""
    Tab = {}
    k = iter(N)
    while 1:
        try:
            d = k.next()
        except StopIteration: break
        if tuple(d) in Tab:
            Tab[tuple(d)] += 1
        else:
            Tab[tuple(d)] = 1
    L = []
    for i,j in Tab.items():
        [i,j]
        L.append([i,j])
    return [i for i in L if (0,0,0,0) not in i]


def stack(D):
    """
    from list of bases at a site D,
    returns an ordered list of counts of bases
    """
    L = len(D)
    counts = []
    for i in range(len(D[0])):
        A=C=T=G=N=S=0
        for nseq in range(L):
            A += D[nseq][i].count("A")
            C += D[nseq][i].count("C")
            T += D[nseq][i].count("T")
            G += D[nseq][i].count("G")
            N += D[nseq][i].count("N")
            S += D[nseq][i].count("-")
        counts.append( [[A,C,T,G],N,S] )
    return counts



def consensus(f, minsamp, endcut):
    """ makes a list of lists of reads at each site """
    f = open(f)
    k = itertools.izip(*[iter(f)]*2)
    L = []
    locus = 0
    while 1:
        try :
            first = k.next()
            fname = first[0]
            S = {}
        except StopIteration: break
        itera = [first[0],first[1]]
        while itera[0] != "//\n":
            nreps = int(itera[0].strip().split(";")[1].replace("size=",""))
            if fname in S:
                for i in range(nreps):
                    S[fname].append(tuple(itera[1].strip()))
            else:
                S[fname] = [tuple(first[1].strip())]
                for i in range(nreps-1):
                    S[fname].append(tuple(itera[1].strip()))
            itera = k.next()
        res = stack(S.values()[0])                                  ## make list for each site in sequences
        ncopies = sum(res[10][0])+res[10][1]+res[10][2]             ## read depth
        if ncopies > (minsamp-1):
            if endcut:
                L += [i[0] for i in res[:-endcut] if i[2] == 0]         ## ignore last x sites
            else:
                L += [i[0] for i in res if i[2] == 0]
            locus += 1
    return L


def optim(handle, minsamp, endcut):
    name = handle.split("/")[-1].replace(".clust","")
    D = consensus(handle, minsamp, endcut)
    P = makeP(D)
    Tab = table_c(D)
    del D
    x0 = [0.01,0.001]
    #H,E = scipy.optimize.fmin(LL,x0,(P,Tab),maxiter=500,maxfun=200,ftol=0.0001,disp=False,full_output=False)
    H,E = scipy.optimize.fmin(LL,x0,(P,Tab),disp=False,full_output=False)
    sys.stderr.write(".")
    return handle,H,E


def main(Parallel,ID,minsamp,endcut,subset,WORK):
    sys.stderr.write("\n\tstep 4: estimating error rate and heterozygosity\n\t")

    " find clust.xx directory "
    if not os.path.exists(WORK+'clust'+ID):
        print  "\terror: could not find "+WORK+"clust"+str(ID)+"/ directory,"+ \
                "\n\t\tif you changed the clustering threshold you must transfer *.clustS"+ \
                "\n\t\tfiles to a new directory named clust.xx with xx replaced by new clustering threshold"
        sys.exit()


    # load up work queue
    work_queue = multiprocessing.Queue()

    # iterate over files
    HH = glob.glob(WORK+"clust"+ID+"/"+subset+"*.clustS*")
    submitted = 0
    if len(HH) > 1:
        ## sort files by size
        for i in range(len(HH)):
            statinfo = os.stat(HH[i])
            HH[i] = HH[i],statinfo.st_size
        HH.sort(key=operator.itemgetter(1))
        FS = [f[0] for f in HH][::-1]
    else:
        FS = HH
    REMOVE = glob.glob(WORK+'clust'+ID+"/cat.*")
    FS = [f for f in FS if f not in REMOVE]
    for handle in FS:
        work_queue.put([handle, minsamp, endcut])
        submitted += 1

    # create a queue to pass to workers to store the results
    result_queue = multiprocessing.Queue()

    # spawn workers
    jobs = []
    for i in range( min(Parallel,submitted) ):
        worker = Worker(work_queue, result_queue, optim)
        worker.start()
        jobs.append(worker)
    for job in jobs:
        job.join()

    # write results to stats file
    results = []
    outstats = open(WORK+"stats/Pi_E_estimate.txt",'w+')
    outstats.write("\t".join(['taxa','H','E'])+"\n")

    E = []
    H = []
    for i in range(len(FS)):
        res = result_queue.get()
        H.append(res[1])
        E.append(res[2])
        res = map(str,res)
        outstats.write("\t".join(res)+"\n")
    outstats.write(" ".join(["mean E =",str(numpy.mean(E))])+"\n")
    outstats.write(" ".join(["mean H =",str(numpy.mean(H))]))
    outstats.close()


