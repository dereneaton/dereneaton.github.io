import os
import sys
import itertools
import numpy
import random
import glob
import subprocess
import pickle



def cluster(UCLUST, ID, radgbs, WORK, complementmatch):
    C = " -cluster_smallmem "+WORK+"prefix/cat.consens_"
    if radgbs:
        P = " -strand both"
        if addon != "R":
            COV = str(complementmatch)
        else:
            COV = ".90"
    else:
        P = " -leftjust "
        COV = ".90"   
    U = " -userout "+WORK+"prefix/cat.u"
    cmd = UCLUST+\
        C+\
        P+\
        " -id "+ID+\
        U+\
        " -userfields query+target+id+gaps+qstrand+qcov"+\
        " -maxaccepts 1"+\
        " -maxrejects 0"+\
        " -fulldp"+\
        " -query_cov "+str(COV)+\
        " -notmatched "+WORK+"prefix/cat._tempU"
        #" -hardmask"+\
    os.system(cmd)




def makeclust(ID,radgbs,WORK):

    ## load .u info into a Dic
    Uin = open(WORK+"prefix/cat.u")
    Fseeds = {}    
    for line in [line.split("\t") for line in Uin.readlines()]:
        if line[1] not in Fseeds:
            Fseeds[line[1]] = [line[0]]
        else:
            Fseeds[line[1]].append(line[0])
    Uin.close()

    
    FS = glob.glob(WORK+"prefix/cat.u_*")
    Useeds = {}
    for f in FS:
        infile = open(f)
        for line in [line.split("\t") for line in infile.readlines()]:
            if line[1] not in Useeds:
                Useeds[line[1]] = [line[0]]
            else:
                Useeds[line[1]].append(line[0])
        infile.close()


    ## extend .u with matches
    D = {}
    for seed in Fseeds:
        # add matches to seed to D[seed]
        Fhits = Useeds.get(seed)
        # add matches to hits to seed to D[seed]
        Mhits = []
        for hit in Fseeds[seed]:
            Mhits.append(hit)
            if Useeds.get(hit):
                Mhits += Useeds.get(hit)
        if Fhits:
            D[seed] = Fhits+Mhits
        else:
            D[seed] = Mhits

    ## load _tempU into D
    f = open(WORK+"prefix/cat._tempU")
    lines = f.readlines()
    for line in lines:
        if ">" in line:
            if line.strip()[1:] not in D:
                if Useeds.get(line.strip()[1:]):
                    #print line.strip()[1:]
                    D[line.strip()[1:]] = Useeds.get(line.strip()[1:])
    f.close()


    ## load .consens files into Dics
    FS = glob.glob(WORK+"clust"+ID+"/cat.consens_*")
    Seqs = {}
    for f in FS:
        ff = open(f)
        k = itertools.izip(*[iter(ff)]*2)
        while 1:
            try: a = k.next()
            except StopIteration: break
            Seqs[a[0].strip()] = a[1].strip()
    
    ## print seqs and names
    outfile = open(WORK+"prefix/cat.clust_", 'w')
    for i in D:
        thisclust = []
        print >>outfile, ">"+i+'\n'+Seqs[">"+i].upper()
        thisclust.append(">"+i+'\n'+Seqs[">"+i].upper())
        for m in D[i]:
            if ">"+m+'\n'+Seqs[">"+m].upper() not in thisclust:
                print >>outfile, ">"+m+'\n'+Seqs[">"+m].upper()
                thisclust.append(">"+m+'\n'+Seqs[">"+m].upper())
        print >>outfile, "//"
    outfile.close()
    
    

def main(UCLUST, ID, radgbs, clustprefix, seed, addon, WORK, complementmatch):
    sys.stderr.write('\n\tstep 6: clustering across cons-samples at '+`ID`+' similarity \n')
    out = open(WORK+'prefix/cat.shuf_','w')

    prefix = clustprefix.split(",")

    seeds = [WORK+"prefix/cat.seed_"+pre for pre in prefix]
    temps = [WORK+"prefix/cat._temp_"+pre for pre in prefix]

    seedseed = set()
    for handle in seeds:
        f = open(handle,'r')
        k = itertools.izip(*[iter(f)]*3)
        while 1:
            try: a = k.next()
            except StopIteration: break
            if len(a[0].strip()) < 20:
                print >>out, a[0].strip()+" "*(20-len(a[0].strip()))+a[1].strip()
            else:
                print >>out, a[0].strip()+" "*((len(a[0].strip())+3)-len(a[0].strip()))+a[1].strip()
            seedseed.add(a[0].strip())
        f.close()
    out.close()

    """ randomize input order """
    if seed:
        random.seed(seed)
    with open(WORK+'prefix/cat.shuf_','r') as source:
        data = [ (random.random(), line) for line in source ]
    data.sort()
    with open(WORK+'prefix/cat.consens_1','w+') as target:
        for _, line in data:
            target.write( line )
    source.close()
    target.close()

    D = open(WORK+"prefix/cat.consens_1").readlines()
    D.sort(key=len)
    k = iter(D[::-1])
    out = open(WORK+'prefix/cat.consens_','w+')
    while 1:
        try: a = k.next().split(" ")
        except StopIteration: break
        ss = a[-1].replace("a","A").replace("g","G").replace("c","C").replace("t","T").strip()
        print >>out, a[0]+'\n'+ss
    out.close()

    cluster(UCLUST,ID,radgbs,WORK, complementmatch)
    makeclust(ID,radgbs,WORK) 

    #if glob.glob(WORK+"prefix/*.seed_*") or glob.glob(WORK+"prefix/*._temp_*"):
    #    os.system("rm "+WORK+"prefix/*.seed_*")
    #    os.system("rm "+WORK+"prefix/*._temp_*")
    #    os.system("rm "+WORK+"prefix/*.u_*")

