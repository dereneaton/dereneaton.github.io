
import os
import numpy
import sys
import random
import itertools
import multiprocessing
from potpour import Worker


def IUPAC(one):
    """
    returns IUPAC symbol for ambiguity bases,
    used for polymorphic sites.
    """
    D = {"R":['G','A'],
         "K":['G','T'],
         "S":['G','C'],
         "Y":['T','C'],
         "W":['T','A'],
         "M":['C','A']}
    return D[one]


def makefreq(patlist):
    " identify which allele is derived in P3 relative to outgroup "
    " and is the most frequent and use that as the SNP "
    P = {}
    for tax in range(len(patlist)):
        P[tax] = []
    for tax in range(len(patlist)):
        for base in patlist[tax]:
            if base in list('ATGC'):
                P[tax].append(base[0])
                P[tax].append(base[0])
            elif base in list("RKSYWM"):
                hh = IUPAC(base[0])
                for i in hh:
                    P[tax].append(i)
    major = [i for i in set(P[2]) if i not in set(P[3])]
    " in case of multiple bases "
    if len(major) > 1:
        cc = [P[2].count(base) for base in major]
        major = major[cc.index(max(cc))]  ## maybe [0]
    elif len(major) == 1:
        major = major[0]
    else:
        major = [i for i in set(P[3]) if i in set(P[2])]
    #print P[0], float(P[0].count(major)), len(P[0])
    try: p1 = float(P[0].count(major))/len(P[0])
    except ZeroDivisionError:
        for i in patlist:
            print i
        print patlist, P, 'zero'
    p2 = float(P[1].count(major))/len(P[1])
    p3 = float(P[2].count(major))/len(P[2])
    o =  float(P[3].count(major))/len(P[3])
    return [p1,p2,p3,o]


def Dstat(ABBA,BABA,pat):
    "takes an ongoing count of ABBA & BABA"
    "and add to it if disc. site in pat"
    if pat[0] != pat[1]:
        if pat[0] == pat[3]:
            if pat[1] == pat[2]:
                ABBA += 1
        else:
            if pat[0] == pat[2]:
                if pat[1] == pat[3]:
                    BABA += 1
    return [ABBA, BABA]



def polyDstat(ABBA,BABA,patlist):
    ## calculate frequencies
    " look at the P3 taxon first for a derived allele "
    p1,p2,p3,o = makefreq(patlist) #[a0,a1,a2,a3])
    ABBA = ((1.-p1)*p2*p3*(1.-o))
    BABA = (p1*(1.-p2)*p3*(1.-o))
    Dft = ABBA - BABA
    Dfb = ABBA + BABA
    return Dft,Dfb,ABBA,BABA
    

def sample_wr(population, k):         
    "used for bootstrap sampling"
    "Chooses k random elements (with replacement) from a population"
    n = len(population)
    _random, _int = random.random, int  # speed hack
    return [_int(_random() * n) for i in itertools.repeat(None, k)]


def IUAfreq(Dft,Dfb,N,L):
    patlist = []
    ABBA = BABA = Dft = Dfb = 0
    k = N.transpose()
    names = k[0,]
    R = k[1:,]
    for site in R:
        p1 = []
        p2 = []
        p3 = []
        o = []
        if len(L[0])>1:
            for i in L[0]:
                p1.append(site[numpy.nonzero(names==i)])
        else:
            p1.append(site[numpy.nonzero(names==L[0])])
        p1 = numpy.concatenate(p1)
        
        if len(L[1])>1:
            for i in L[1]:
                p2.append(site[numpy.nonzero(names==i)])
        else:
            p2.append(site[numpy.nonzero(names==L[1])])
        p2 = numpy.concatenate(p2)
        
        if len(L[2])>1:
            for i in L[2]:
                p3.append(site[numpy.nonzero(names==i)])
        else:
            p3.append(site[numpy.nonzero(names==L[2])])
        p3 = numpy.concatenate(p3)
        
        if len(L[3])>1:
            for i in L[3]:
                o.append(site[numpy.nonzero(names==i)])
        else:
            o.append(site[numpy.nonzero(names==L[3])])
        o = numpy.concatenate(o)
        patlist = [p1,p2,p3,o]
        if not any([all([i in ["N",'-'] for i in patlist[0]]),
                    all([i in ["N",'-'] for i in patlist[1]]),
                    all([i in ["N",'-'] for i in patlist[2]]),
                    all([i in ["N",'-'] for i in patlist[3]])]):
            if any([i not in patlist[3] for i in patlist[2]]):
                dft,dfb,abba,baba = polyDstat(ABBA,BABA,patlist)
                ABBA += abba
                BABA += baba
            else:
                dft,dfb = [0.,0.]
        else:
            dft, dfb = [0.,0.]
        Dft += dft
        Dfb += dfb
    return Dft,Dfb,ABBA,BABA


def IUA(N,L):
    ABBA = BABA = 0
    k = N.transpose()
    names = k[0,]
    R = k[1:,]
    for site in R:
        pat = [ site[numpy.nonzero(names==L[0])],
                site[numpy.nonzero(names==L[1])],
                site[numpy.nonzero(names==L[2])],
                site[numpy.nonzero(names==L[3])] ]
        if all(i in list('ATGC') for i in pat):
            if len(set(pat[0][0]+pat[1][0]+pat[2][0]+pat[3][0])) == 2:
                [ABBA,BABA] = Dstat(ABBA,BABA,pat) ####
    return ABBA,BABA



def bootfreq(D):
    which = iter(sample_wr(range(len(D)),len(D)))
    bootlist = []
    Dftop = Dfbot = 0
    while 1:
        try: d = which.next()
        except StopIteration: break
        if D[d]:
            a,b = D[d]
            Dftop += a
            Dfbot += b
    D = 0.
    if Dfbot > 0:
        D = Dftop/float(Dfbot)
    return D
    


def boot2(D):
    which = iter(sample_wr(range(len(D)),len(D)))
    bootlist = []
    abba = baba = 0
    while 1:
        try: d = which.next()
        except StopIteration: break
        if D[d]:
            a,b = D[d]
            abba += a
            baba += b
    if abba+baba > 0:
        D = float(abba-baba)/float(abba+baba)
    else:
        D = 0.
    return D


def runtest(infile,L,nboots,snpfreq, submitted):
    f = open(infile)
    k = iter(f)
    D = []
    tABBA = tBABA = Dft = Dfb = 0
    while 1:
        P = {}
        try: d = k.next()
        except StopIteration: break
        while '//' not in d:
            a = d.split(" ")[0]
            b = d.strip().split(" ")[-1]
            if ">" in a:
                P[a.replace(">","")] = b.strip()
            d = k.next()
        if snpfreq:
            for tax in L:
                z = any([tax in P for tax in L[0]])
                y = any([tax in P for tax in L[1]])
                w = any([tax in P for tax in L[2]])
                u = any([tax in P for tax in L[3]])
            if all([z,y,w,u]):
                N = numpy.array([[i]+list(P[i]) for i in P])
                dft,dfb,abba,baba = IUAfreq(Dft,Dfb,N,L)
                #if (dft or dfb): print dft,dfb
                Dft += dft
                Dfb += dfb
                tABBA += abba
                tBABA += baba
                D.append([dft,dfb]) ## save values for bootstrapping
        else:
            if all(tax in P for tax in L):
                N = numpy.array([[i]+list(P[i]) for i in P])
                abba,baba = IUA(N,L)
                tABBA += abba
                tBABA += baba
                D.append([abba,baba])   ## save values for bootstrapping
    if snpfreq:
        dftfinal = sum([i[0] for i in D])
        dbtfinal = sum([i[1] for i in D])
        if dbtfinal > 0:
            Dfinal = dftfinal/dbtfinal
        else:
            Dfinal = 0.
        if len(D) > 0:
            pdisc = (float(len([i for i in D if any([j for j in i])])) / len(D))
        else: pdisc = 0.
        BB = []
        for i in range(nboots):
            bb = bootfreq(D)
            BB.append(bb)
        STD = numpy.std(BB)
    else:
        if tABBA+tBABA > 0:
            Dfinal = ((tABBA-tBABA)/float(tABBA+tBABA))
        else:
            Dfinal = 0.
        if len(D) > 0:
            pdisc = (float(len([i for i in D if any([j for j in i])])) / len(D))
        else: pdisc = 0.
        BB = []
        for i in range(nboots):
            bb = boot2(D)
            BB.append(bb)
        STD = numpy.std(BB)
    if STD < 0.00001:
        STD = 0.
    if Dfinal != 0.0:
        if STD != 0.0:
            Z = (abs(Dfinal/STD))
        else:
            Z = "NA"
    else:
        Dfinal = 0.
        Z = 0.
    sys.stderr.write(".")
    return [L,Dfinal,STD,Z,len(D),tABBA,tBABA,pdisc,submitted]




def main(tests, alignfile, nboots, nproc):
    import sys
    print >>sys.stdout, "\t".join([ 'P1','P2','P3','O',
                                    'D','SD','Z','BABA','ABBA',
                                    'nloci','nboot','pdisc','notes'])
    print >>sys.stdout, "-"*30+"="*21+'-'*55

    work_queue = multiprocessing.Queue()
    result_queue = multiprocessing.Queue()
    submitted = 0
    Notes = []
    for rep in tests:
        notes = ""
        if len(rep) == 2:
            rep,notes = rep
        p1,p2,p3,o = rep
        if all(["[" in i for i in rep[1:]]):
            p1 = p1[1:-1].split(",")
            p2 = p2[1:-1].split(",")
            p3 = p3[1:-1].split(",")
            o =   o[1:-1].split(",")
            work_queue.put([alignfile,[p1,p2,p3,o],nboots,1, submitted])
            submitted += 1
        else:
            work_queue.put([alignfile,[p1,p2,p3,o],nboots,0, submitted])
            submitted += 1
        Notes.append(notes)
    jobs = []
    for i in range(nproc):
        worker = Worker(work_queue, result_queue, runtest)
        jobs.append(worker)
        worker.start()
    for j in jobs:
        j.join()

    Results = [result_queue.get() for i in range(submitted)]
    Results.sort(key = lambda x:x[8])
    for i in range(len(Results)):
        ps,D,STD,Z,nsites,ABBA,BABA,pdisc,sub = Results[i]
        ps = [str(x).replace("['","[").replace("']","]").replace("', '",",") for x in ps]
        print >>sys.stdout, "\t".join(map(str,[str(ps[0]).replace(">",""),
                                               str(ps[1]).replace(">",""),
                                               str(ps[2]).replace(">",""),
                                               str(ps[3]).replace(">",""),
                                               round(D,4),round(STD,4),
                                               str(Z)[0:6],
                                               str(BABA)[0:6],
                                               str(ABBA)[0:6],
                                               nsites,
                                               nboots,round(pdisc,4),
                                               Notes[i]]))

if __name__ == '__main__':
    main()

