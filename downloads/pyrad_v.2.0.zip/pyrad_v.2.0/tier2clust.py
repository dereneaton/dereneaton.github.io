import os
import sys
import itertools
import numpy
import random
import glob
import subprocess
import pickle
import gzip



def cluster(UCLUST, ID, datatype, WORK):
    C = " -cluster_smallmem "+WORK+"prefix/cat.consens_"

    if datatype in ['gbs','pairgbs']:
        P = " -strand both"
        COV = ".90"
    else:
        P = " -leftjust "
        COV = ".90"   
    U = " -userout "+WORK+"prefix/cat.u"
    cmd = UCLUST+\
        C+\
        P+\
        " -id "+ID+\
        U+\
        " -userfields query+target+id+gaps+qstrand+qcov"+\
        " -maxaccepts 1"+\
        " -maxrejects 0"+\
        " -fulldp"+\
        " -query_cov "+str(COV)+\
        " -notmatched "+WORK+"prefix/cat._tempU"
        #" -hardmask"+\
    os.system(cmd)




def makeclust(ID, datatype, WORK):

    " load tier 2 hits into a Dic "
    Uin = open(WORK+"prefix/cat.u")
    Fseeds = {}    
    for line in [line.split("\t") for line in Uin.readlines()]:
        if line[1] not in Fseeds:
            Fseeds[line[1]] = [line[0]]
        else:
            Fseeds[line[1]].append(line[0])
    Uin.close()


    " load tier 1 hits into a Dictionary "
    FS = glob.glob(WORK+"prefix/cat.u_*")
    Useeds = {}
    for f in FS:
        infile = open(f)
        for line in [line.split("\t") for line in infile.readlines()]:
            if line[1] not in Useeds:
                Useeds[line[1]] = [line[0]]
            else:
                Useeds[line[1]].append(line[0])
        infile.close()


    " extend .u with matches "
    D = {}
    for seed in Fseeds:
        # add matches to seed to D[seed]
        Fhits = Useeds.get(seed)
        # add matches to hits to seed to D[seed]
        Mhits = []
        for hit in Fseeds[seed]:
            Mhits.append(hit)
            if Useeds.get(hit):
                Mhits += Useeds.get(hit)
        if Fhits:
            D[seed] = Fhits+Mhits
        else:
            D[seed] = Mhits

    " load seeds of tier 2 into D "
    f = open(WORK+"prefix/cat._tempU")
    lines = f.readlines()
    for line in lines:
        if ">" in line:
            if line.strip()[1:] not in D:
                if Useeds.get(line.strip()[1:]):
                    D[line.strip()[1:]] = Useeds.get(line.strip()[1:])
    f.close()


    " TODO replace w/ haplos "
    " load .consens files into Dics "
    FS = glob.glob(WORK+"clust"+ID+"/cat.consens_*.gz")
    Seqs = {}
    for f in FS:
        with gzip.open(f) as ff:
            k = itertools.izip(*[iter(ff)]*2)
            while 1:
                try: a = k.next()
                except StopIteration: break
                Seqs[a[0].strip()] = a[1].strip()
    

    " write clust file "
    outfile = gzip.open(WORK+"prefix/cat.clust_.gz", 'w')
    for i in D:
        thisclust = []
        outfile.write(">"+i+'\n'+Seqs[">"+i].upper()+'\n')
        thisclust.append(">"+i+'\n'+Seqs[">"+i].upper())
        for m in D[i]:
            if ">"+m+'\n'+Seqs[">"+m].upper() not in thisclust:
                outfile.write(">"+m+'\n'+Seqs[">"+m].upper()+'\n')
                thisclust.append(">"+m+'\n'+Seqs[">"+m].upper())
        outfile.write("//\n")
    outfile.close()
    
    

def main(UCLUST, ID, datatype,
         gids, seed, WORK):
    
    sys.stderr.write('\n\tstep 6: clustering across cons-samples at '+`ID`+' similarity \n')

    " read in all seeds and hits "
    seeds = [WORK+"prefix/cat.seed_"+gid for gid in gids]
    temps = [WORK+"prefix/cat._temp_"+gid for gid in gids]

    #print seeds
    #print temps

    " read in all seeds and make same length for randomizing "
    out = gzip.open(WORK+'prefix/cat.group_.gz','wb')
    for handle in seeds:
        f = open(handle,'r')
        k = itertools.izip(*[iter(f)]*3)
        while 1:
            try: a = k.next()
            except StopIteration: break
            if len(a[0].strip()) < 20:
                out.write(a[0].strip()+" "*(20-len(a[0].strip()))+a[1])
            else:
                out.write(a[0].strip()+" "*((len(a[0].strip())+3)-len(a[0].strip()))+a[1])
        f.close()
    out.close()

    """ randomize input order """
    if seed:
        random.seed(seed)
    with gzip.open(WORK+'prefix/cat.group_.gz','rb') as source:
        data = [ (random.random(), line) for line in source ]
    data.sort()

    """ sort by length while preserving randomization within size classes """
    D = [line for _,line in data]
    D.sort(key=len, reverse=True)
    k = iter(D)
    out = open(WORK+'prefix/cat.consens_','w')
    while 1:
        try: a = k.next().split(" ")
        except StopIteration: break
        ss = a[-1].replace("a","A").replace("g","G").replace("c","C").replace("t","T").strip()
        print >>out, a[0]+'\n'+ss
    out.close()

    cluster(UCLUST, ID, datatype, WORK)
    makeclust(ID, datatype, WORK)


    #if glob.glob(WORK+"prefix/*.seed_*") or glob.glob(WORK+"prefix/*._temp_*"):
    #    os.system("rm "+WORK+"prefix/*.seed_*")
    #    os.system("rm "+WORK+"prefix/*._temp_*")
    #    os.system("rm "+WORK+"prefix/*.u_*")

